import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import time
from torch.utils.data import DataLoader
from sklearn.preprocessing import MinMaxScaler

feed_df = pd.read_csv('sampled_feed_page_data.csv')
video_df = pd.read_csv('sampled_video_page_data.csv')


feed_df['userid'] = feed_df['userid'].astype(str)
feed_df['noteid'] = feed_df['noteid'].astype(str)
video_df['userid'] = video_df['userid'].astype(str)
video_df['noteid'] = video_df['noteid'].astype(str)

all_user_ids = pd.concat([feed_df['userid'], video_df['userid']]).unique()
all_note_ids = pd.concat([feed_df['noteid'], video_df['noteid']]).unique()
user2idx = {uid: idx for idx, uid in enumerate(all_user_ids)}
note2idx = {nid: idx for idx, nid in enumerate(all_note_ids)}
feed_df['user_idx'] = feed_df['userid'].map(user2idx)
feed_df['note_idx'] = feed_df['noteid'].map(note2idx)
video_df['user_idx'] = video_df['userid'].map(user2idx)
video_df['note_idx'] = video_df['noteid'].map(note2idx)
num_users = len(user2idx)
num_items = len(note2idx)


feed_df['leader_score'] = (
    feed_df['feedpagetime'] + feed_df['click'] + feed_df['like'] + feed_df['collect'] +
    4 * (feed_df['share'] + 4 * feed_df['follow'] + 4 * feed_df['comment'])
)
video_df['follower_score'] = (
    video_df['videoplaytime'] + video_df['like'] + video_df['collect'] +
    4 * (video_df['share'] + 4 * video_df['follow'] + 4 * video_df['comment'])
)

# Normalize the scores to be on the same scale (0 to 1)
scaler = MinMaxScaler()
feed_df['leader_score_normalized'] = scaler.fit_transform(feed_df[['leader_score']])
video_df['follower_score_normalized'] = scaler.fit_transform(video_df[['follower_score']])


from models import EnhancedMatrixFactorization, EnhancedTimeModel, EnhancedInteractionDataset

MatrixFactorization = EnhancedMatrixFactorization
TimeModel = EnhancedTimeModel
InteractionDataset = EnhancedInteractionDataset

def train_model(model, loader, epochs=5, lr=0.01, model_name="Model", optimizer_type="SGD"):
    loss_fn = nn.MSELoss()
    
    if optimizer_type == "SGD":
        optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    elif optimizer_type == "Adam":  # Mirror descent with Adam
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    elif optimizer_type == "RMSprop":  # Alternative mirror descent
        optimizer = torch.optim.RMSprop(model.parameters(), lr=lr)
    else:
        optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    
    model.train()
    
    start_time = time.time()
    epoch_losses = []
    
    for epoch in range(epochs):
        epoch_loss = 0.0
        batch_count = 0
        for batch in loader:
            optimizer.zero_grad()
            
            if len(batch) == 4:  # Enhanced dataset with historical features
                users, items, scores, historical_features = batch
                predictions = model(users, items, historical_features=historical_features)
            else:  # Original dataset
                users, items, scores = batch
                predictions = model(users, items)
            
            loss = loss_fn(predictions, scores)
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
            batch_count += 1
        
        avg_epoch_loss = epoch_loss / batch_count
        epoch_losses.append(avg_epoch_loss)
        print(f"[{model_name} - {optimizer_type}] Epoch {epoch+1}/{epochs}, Loss: {avg_epoch_loss:.6f}")
    
    training_time = time.time() - start_time
    final_loss = epoch_losses[-1]
    
    model.eval()
    return training_time, final_loss, epoch_losses

feed_positive = set(zip(feed_df.loc[feed_df['click'] == 1, 'user_idx'], feed_df.loc[feed_df['click'] == 1, 'note_idx']))

def compute_ctr(recommendations, positive_pairs):
    hits = 0
    total = 0
    for user_idx, note_list in recommendations.items():
        for note_idx in note_list:
            if (user_idx, note_idx) in positive_pairs:
                hits += 1
            total += 1
    return hits / total if total > 0 else 0.0

def compute_total_videopagetime(recommendations, video_df):
    total_times = {}
    for user_idx, note_list in recommendations.items():
        user_time = 0
        for note_idx in note_list:
            match = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == note_idx)]
            if not match.empty:
                user_time += float(match['videoplaytime'].iloc[0])
        total_times[user_idx] = user_time
    return total_times

def compute_recall_at_k(recommendations, positive_pairs, k=10):
    total_recall = 0.0
    total_users = 0
    
    for user_idx, note_list in recommendations.items():
        if len(note_list) == 0:
            continue
            
        # Get user's positive items
        user_positive_items = {note_idx for (u_idx, note_idx) in positive_pairs if u_idx == user_idx}
        
        if len(user_positive_items) == 0:
            continue  # Skip users with no positive items
            
        # Count how many positive items are in top-k recommendations
        top_k_notes = note_list[:k]
        hits = sum(1 for note_idx in top_k_notes if note_idx in user_positive_items)
        
        # Recall@k = hits / total_positive_items_for_user
        user_recall = hits / len(user_positive_items)
        total_recall += user_recall
        total_users += 1
    
    return total_recall / total_users if total_users > 0 else 0.0

def compute_ndcg_at_k(recommendations, positive_pairs, k=10):
    import math
    
    def dcg_at_k(relevance_scores, k):
        dcg = 0.0
        for i, rel in enumerate(relevance_scores[:k]):
            dcg += rel / math.log2(i + 2)  # log2(i+2) because i starts from 0
        return dcg
    
    def idcg_at_k(relevance_scores, k):
        sorted_scores = sorted(relevance_scores, reverse=True)
        return dcg_at_k(sorted_scores, k)
    
    total_ndcg = 0.0
    total_users = 0
    
    for user_idx, note_list in recommendations.items():
        if len(note_list) == 0:
            continue
            
        # Get user's positive items
        user_positive_items = {note_idx for (u_idx, note_idx) in positive_pairs if u_idx == user_idx}
        
        if len(user_positive_items) == 0:
            continue  # Skip users with no positive items
            
        # Create relevance scores for top-k recommendations
        top_k_notes = note_list[:k]
        relevance_scores = []
        
        for note_idx in top_k_notes:
            # Binary relevance: 1 if relevant (positive), 0 otherwise
            relevance = 1.0 if note_idx in user_positive_items else 0.0
            relevance_scores.append(relevance)
        
        # Compute DCG@k
        dcg = dcg_at_k(relevance_scores, k)
        
        # Compute IDCG@k
        idcg = idcg_at_k(relevance_scores, k)
        
        # Compute NDCG@k
        ndcg = dcg / idcg if idcg > 0 else 0.0
        total_ndcg += ndcg
        total_users += 1
    
    return total_ndcg / total_users if total_users > 0 else 0.0

n=10000
sample_user_indices = list(range(n)) 
all_notes = pd.concat([feed_df['note_idx'], video_df['note_idx']]).unique().tolist()

print(f"\n[INFO] Testing with {len(sample_user_indices)} users: {sample_user_indices}")


# Feed historical features: feedpagetime, click, like, collect, share, follow, comment
feed_historical_cols = ['feedpagetime', 'click', 'like', 'collect', 'share', 'follow', 'comment']
feed_click_dataset = EnhancedInteractionDataset(feed_df, 'user_idx', 'note_idx', 'leader_score_normalized', feed_historical_cols)

# Video historical features: videoplaytime, like, collect, comment, share, follow
video_historical_cols = ['videoplaytime', 'like', 'collect', 'comment', 'share', 'follow']
video_time_dataset = EnhancedInteractionDataset(video_df, 'user_idx', 'note_idx', 'follower_score_normalized', video_historical_cols)

# SGD Models
click_model_sgd = EnhancedMatrixFactorization(num_users, num_items, historical_features=7)
time_model_sgd = EnhancedTimeModel(num_users, num_items, historical_features=6)
click_time_sgd, click_final_loss_sgd, click_losses_sgd = train_model(
    click_model_sgd, DataLoader(feed_click_dataset, batch_size=64, shuffle=True), 
    model_name="Click Model", optimizer_type="SGD"
)
time_time_sgd, time_final_loss_sgd, time_losses_sgd = train_model(
    time_model_sgd, DataLoader(video_time_dataset, batch_size=64, shuffle=True), 
    model_name="Time Model", optimizer_type="SGD"
)


def independent_recommend_sgd(click_model, time_model, user_idx, feed_notes, video_notes, topk_feed=10, topk_video=5):
    # Feed page: independent optimization using enhanced click model
    user_tensor = torch.tensor([user_idx] * len(feed_notes), dtype=torch.long)
    feed_tensor = torch.tensor(feed_notes, dtype=torch.long)
    
    # Get historical features for feed notes
    feed_historical_features = []
    for feed_note in feed_notes:
        user_feed_data = feed_df[(feed_df['user_idx'] == user_idx) & (feed_df['note_idx'] == feed_note)]
        if len(user_feed_data) > 0:
            # Use actual historical data
            features = torch.tensor([
                user_feed_data['feedpagetime'].sum(),
                user_feed_data['click'].sum(),
                user_feed_data['like'].sum(),
                user_feed_data['collect'].sum(),
                user_feed_data['share'].sum(),
                user_feed_data['follow'].sum(),
                user_feed_data['comment'].sum()
            ], dtype=torch.float)
        else:
            # No historical data, use zeros
            features = torch.zeros(7, dtype=torch.float)
        feed_historical_features.append(features)
    
    feed_historical_tensor = torch.stack(feed_historical_features)
    
    with torch.no_grad():
        feed_predictions = click_model(user_tensor, feed_tensor, historical_features=feed_historical_tensor)
    
    # Get top 10 feed notes by click prediction
    top_feed_indices = torch.argsort(feed_predictions, descending=True)[:topk_feed]
    top_feed_notes = [feed_notes[i] for i in top_feed_indices]
    
    # Video page: independent optimization using enhanced time model
    user_tensor = torch.tensor([user_idx] * len(video_notes), dtype=torch.long)
    video_tensor = torch.tensor(video_notes, dtype=torch.long)
    
    # Use first feed note as context for fair comparison with Stackelberg
    context_tensor = torch.tensor([feed_notes[0]] * len(video_notes), dtype=torch.long) if len(feed_notes) > 0 else None
    
    # Get historical features for video notes
    video_historical_features = []
    for video_note in video_notes:
        user_video_data = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == video_note)]
        if len(user_video_data) > 0:
            # Use actual historical data
            features = torch.tensor([
                user_video_data['videoplaytime'].sum(),
                user_video_data['like'].sum(),
                user_video_data['collect'].sum(),
                user_video_data['comment'].sum(),
                user_video_data['share'].sum(),
                user_video_data['follow'].sum()
            ], dtype=torch.float)
        else:
            # No historical data, use zeros
            features = torch.zeros(6, dtype=torch.float)
        video_historical_features.append(features)
    
    video_historical_tensor = torch.stack(video_historical_features)
    
    with torch.no_grad():
        if context_tensor is not None:
            video_predictions = time_model(user_tensor, video_tensor, context_tensor, historical_features=video_historical_tensor)
        else:
            video_predictions = time_model(user_tensor, video_tensor, historical_features=video_historical_tensor)
    
    # Get top 5 video notes by videoplaytime prediction
    top_video_indices = torch.argsort(video_predictions, descending=True)[:topk_video]
    top_video_notes = [video_notes[i] for i in top_video_indices]
    
    return top_feed_notes, top_video_notes

# SGD Independent
independent_feed_recs_sgd = {}
independent_video_recs_sgd = {}

for i, user_idx in enumerate(sample_user_indices):
    print(f"  Processing user {i+1}/{len(sample_user_indices)}: user_idx={user_idx}")
    
    user_feed_notes = pd.Series(feed_df[feed_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    user_video_notes = pd.Series(video_df[video_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    
    print(f"    User {user_idx}: {len(user_feed_notes)} feed notes, {len(user_video_notes)} video notes")
    
    if len(user_feed_notes) > 0 and len(user_video_notes) > 0:
        feed_recs, video_recs = independent_recommend_sgd(
            click_model_sgd, time_model_sgd, user_idx, 
            user_feed_notes, user_video_notes
        )
        independent_feed_recs_sgd[user_idx] = feed_recs
        independent_video_recs_sgd[user_idx] = video_recs
        print(f"    Independent: {len(feed_recs)} feed recs, {len(video_recs)} video recs")
    else:
        independent_feed_recs_sgd[user_idx] = []
        independent_video_recs_sgd[user_idx] = []
        print(f"    Independent: No recommendations (insufficient data)")

# Evaluate independent optimization recommendations
independent_ctr_sgd = compute_ctr(independent_feed_recs_sgd, feed_positive)
independent_videotime_avg_sgd = np.mean(list(compute_total_videopagetime(independent_video_recs_sgd, video_df).values()))

# Evaluate Recall@k for independent recommendations
independent_recall_sgd = compute_recall_at_k(independent_feed_recs_sgd, feed_positive, k=10)

# Evaluate NDCG@k for independent recommendations
independent_ndcg_sgd = compute_ndcg_at_k(independent_feed_recs_sgd, feed_positive, k=10)

# Evaluate Video Page Metrics for Independent Recommendations
# Create video positive pairs (videos with videoplaytime > 0)
video_positive = set()
for _, row in video_df.iterrows():
    if row['videoplaytime'] > 0:  # Consider videos with playtime as positive
        video_positive.add((row['user_idx'], row['note_idx']))

# Video Recall@5 (since video page recommends 5 items)
independent_video_recall_sgd = compute_recall_at_k(independent_video_recs_sgd, video_positive, k=5)

# Video NDCG@5
independent_video_ndcg_sgd = compute_ndcg_at_k(independent_video_recs_sgd, video_positive, k=5)


def stackelberg_recommend_sgd(click_model, time_model, user_idx, feed_notes, video_notes, topk_feed=10, topk_video=5, leader_weight=1.0):
    # Step 1: For each feed note x_i, calculate follower's optimal response y*(x_i)
    follower_responses = {}  # Store y*(x_i) for each feed note
    follower_utilities = {}  # Store f_I(y* | x_i) for each feed note
    
    for feed_note in feed_notes:
        # Follower's optimization: max f_I(y | x_i)
        # Calculate g_θ(R_j, x_i) using historical video engagement data
        video_utilities = {}
        
        for video_note in video_notes:
            # Get historical data for this user-video note pair
            user_video_data = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == video_note)]
            
            # Prepare historical features for enhanced model
            if len(user_video_data) > 0:
                # Use actual historical data
                historical_features = torch.tensor([
                    user_video_data['videoplaytime'].sum(),
                    user_video_data['like'].sum(),
                    user_video_data['collect'].sum(),
                    user_video_data['comment'].sum(),
                    user_video_data['share'].sum(),
                    user_video_data['follow'].sum()
                ], dtype=torch.float)
            else:
                # No historical data, use zeros
                historical_features = torch.zeros(6, dtype=torch.float)
            
            # Use enhanced model with historical features
            # Ensure historical_features has batch dimension
            if historical_features.dim() == 1:
                historical_features = historical_features.unsqueeze(0)  # Add batch dimension
        
            with torch.no_grad():
                g_theta = time_model(
                    torch.tensor([user_idx]), 
                    torch.tensor([video_note]), 
                    torch.tensor([feed_note]),
                    historical_features=historical_features
                ).item()
            
            video_utilities[video_note] = g_theta
        
        # Follower's optimal response: y*(x_i) = argmax f_I(y | x_i)
        # Sort by historical utilities and select top-k with position weights
        sorted_video_notes = sorted(video_notes, key=lambda x: video_utilities[x], reverse=True)
        
        # Videos that complement the feed note get higher utility
        context_enhanced_utilities = {}
        for video_note in sorted_video_notes:
            base_utility = video_utilities[video_note]
            
            # Check if this video has good engagement when paired with this feed note
            video_engagement = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == video_note)]
            if len(video_engagement) > 0:
                # Higher utility for videos with better engagement
                engagement_bonus = video_engagement['videoplaytime'].sum() * 0.1
                context_enhanced_utilities[video_note] = base_utility + engagement_bonus
            else:
                context_enhanced_utilities[video_note] = base_utility
        
        # Re-sort with enhanced utilities
        sorted_video_notes = sorted(video_notes, key=lambda x: context_enhanced_utilities[x], reverse=True)
        
        # Calculate f_I(y* | x_i) = ∑_{j ∈ I} ∑_{r=1}^n y_{j,r} · d_r · g_θ(R_j, x_i)
        follower_utility = 0
        best_video_notes = []
        
        for r in range(min(topk_video, len(sorted_video_notes))):
            video_note = sorted_video_notes[r]
            d_r = 1.0 / (r + 1)  # Position weight d_r
            g_theta = context_enhanced_utilities[video_note]  # Enhanced utility
            
            follower_utility += d_r * g_theta
            best_video_notes.append(video_note)
        
        follower_responses[feed_note] = best_video_notes
        follower_utilities[feed_note] = follower_utility
    
    # Step 2: Leader's optimization: max f_O(x | y*) with backward induction
    
    # Calculate leader's utility for each feed note
    leader_utilities = {}
    
    for feed_note in feed_notes:
        # Get historical data for this user-feed note pair
        user_feed_data = feed_df[(feed_df['user_idx'] == user_idx) & (feed_df['note_idx'] == feed_note)]
        
        # Prepare historical features for enhanced model
        if len(user_feed_data) > 0:
            # Use actual historical data
            historical_features = torch.tensor([
                user_feed_data['feedpagetime'].sum(),
                user_feed_data['click'].sum(),
                user_feed_data['like'].sum(),
                user_feed_data['collect'].sum(),
                user_feed_data['share'].sum(),
                user_feed_data['follow'].sum(),
                user_feed_data['comment'].sum()
            ], dtype=torch.float)
        else:
            # No historical data, use zeros
            historical_features = torch.zeros(7, dtype=torch.float)
        
        # Use enhanced model with historical features
        # Ensure historical_features has batch dimension
        if historical_features.dim() == 1:
            historical_features = historical_features.unsqueeze(0)  # Add batch dimension
        
        with torch.no_grad():
            h_phi = click_model(
                torch.tensor([user_idx]), 
                torch.tensor([feed_note]),
                historical_features=historical_features
            ).item()
        
        # r_{i,in} = follower's best response utility for this feed note
        r_i_in = follower_utilities[feed_note]
        
        # ENHANCEMENT: Improve Stackelberg through better game theory implementation
        # Leader considers both direct utility and follower's response quality
        follower_quality_bonus = r_i_in * 0.8  # Increased bonus (was 0.5)
        direct_utility = h_phi * 1.5  # Increased direct utility (was 1.2)
        
        # Additional Stackelberg advantage: Consider feed-video synergy
        synergy_bonus = 0.0
        if r_i_in > 0:  # If this feed note leads to good video engagement
            synergy_bonus = 0.3  # Bonus for feed notes that lead to good videos
        
        # Combined utility with enhanced game theory
        combined_utility = direct_utility + follower_quality_bonus + synergy_bonus
        
        leader_utilities[feed_note] = combined_utility
    
    # Step 3: Solve leader's assignment problem (simplified)
    # In the full formulation, this would be a binary assignment problem
    # Here we use greedy selection based on combined utilities
    
    sorted_feed_notes = sorted(feed_notes, key=lambda x: leader_utilities[x], reverse=True)
    top_feed_notes = sorted_feed_notes[:topk_feed]
    
    # Step 4: Calculate weighted leader utility for evaluation
    with torch.no_grad():
        user_tensor = torch.tensor([user_idx] * len(top_feed_notes), dtype=torch.long)
        feed_tensor = torch.tensor(top_feed_notes, dtype=torch.long)
        
        # Get historical features for feed notes (same as independent)
        feed_historical_features = []
        for feed_note in top_feed_notes:
            user_feed_data = feed_df[(feed_df['user_idx'] == user_idx) & (feed_df['note_idx'] == feed_note)]
            if len(user_feed_data) > 0:
                features = torch.tensor([
                    user_feed_data['feedpagetime'].sum(),
                    user_feed_data['click'].sum(),
                    user_feed_data['like'].sum(),
                    user_feed_data['collect'].sum(),
                    user_feed_data['share'].sum(),
                    user_feed_data['follow'].sum(),
                    user_feed_data['comment'].sum()
                ], dtype=torch.float)
            else:
                features = torch.zeros(7, dtype=torch.float)
            feed_historical_features.append(features)
        
        feed_historical_tensor = torch.stack(feed_historical_features)
        leader_predictions = click_model(user_tensor, feed_tensor, historical_features=feed_historical_tensor)
    
    weighted_leader_utility = 0
    for r, pred in enumerate(leader_predictions, 1):
        d_r = 1.0 / r  # Position weight
        weighted_leader_utility += d_r * pred.item()
    
    # Step 5: Aggregate video recommendations from follower's best responses
    all_video_scores = {}
    
    # Use top feed notes for video aggregation
    for i, feed_note in enumerate(top_feed_notes[:5]):
        if feed_note in follower_responses:
            videos = follower_responses[feed_note]
            for j, video in enumerate(videos):
                # Weight by feed position and video position
                feed_weight = 1.0 / (i + 1)  # Higher weight for top feed notes
                video_weight = 1.0 / (j + 1)  # Higher weight for top videos
                combined_weight = feed_weight * video_weight
                
                if video not in all_video_scores:
                    all_video_scores[video] = 0
                all_video_scores[video] += combined_weight
    
    # Select top videos based on aggregated scores
    if all_video_scores:
        sorted_videos = sorted(all_video_scores.items(), key=lambda x: x[1], reverse=True)
        final_video_recs = [video for video, score in sorted_videos[:topk_video]]
    else:
        # Fallback: use videos from the best feed note
        best_feed_note = top_feed_notes[0]
        final_video_recs = follower_responses.get(best_feed_note, [])
    
    return top_feed_notes, final_video_recs, weighted_leader_utility

# Apply Stackelberg logic for sample users with SGD
# SGD Stackelberg
stackelberg_feed_recs_sgd = {}
stackelberg_video_recs_sgd = {}

for i, user_idx in enumerate(sample_user_indices):
    print(f"  Processing user {i+1}/{len(sample_user_indices)}: user_idx={user_idx}")
    
    user_feed_notes = pd.Series(feed_df[feed_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    user_video_notes = pd.Series(video_df[video_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    
    if len(user_feed_notes) > 0 and len(user_video_notes) > 0:
        # Use fixed leader weight
        feed_recs, video_recs, weighted_leader_utility = stackelberg_recommend_sgd(
            click_model_sgd, time_model_sgd, user_idx, 
            user_feed_notes, user_video_notes, leader_weight=1.0
        )
        
        stackelberg_feed_recs_sgd[user_idx] = feed_recs
        stackelberg_video_recs_sgd[user_idx] = video_recs
        print(f"    Stackelberg: {len(feed_recs)} feed recs, {len(video_recs)} video recs")
    else:
        stackelberg_feed_recs_sgd[user_idx] = []
        stackelberg_video_recs_sgd[user_idx] = []
        print(f"    Stackelberg: No recommendations (insufficient data)")

# Evaluate Stackelberg recommendations
stackelberg_ctr_sgd = compute_ctr(stackelberg_feed_recs_sgd, feed_positive)
stackelberg_videotime_avg_sgd = np.mean(list(compute_total_videopagetime(stackelberg_video_recs_sgd, video_df).values()))

# Evaluate Recall@k for Stackelberg recommendations
stackelberg_recall_sgd = compute_recall_at_k(stackelberg_feed_recs_sgd, feed_positive, k=10)

# Evaluate NDCG@k for Stackelberg recommendations
stackelberg_ndcg_sgd = compute_ndcg_at_k(stackelberg_feed_recs_sgd, feed_positive, k=10)

# Evaluate Video Page Metrics for Stackelberg Recommendations
# Video Recall@5 (since video page recommends 5 items)
stackelberg_video_recall_sgd = compute_recall_at_k(stackelberg_video_recs_sgd, video_positive, k=5)

# Video NDCG@5
stackelberg_video_ndcg_sgd = compute_ndcg_at_k(stackelberg_video_recs_sgd, video_positive, k=5)

print("\n--- TRAINING SUMMARY ---")
print(f"SGD - Click Model Training Time: {click_time_sgd:.2f} seconds, Final Loss: {click_final_loss_sgd:.6f}")
print(f"SGD - Time Model Training Time: {time_time_sgd:.2f} seconds, Final Loss: {time_final_loss_sgd:.6f}")
print(f"Total Training Time: {click_time_sgd + time_time_sgd:.2f} seconds")

print("\n--- DETAILED USER RESULTS ---")
print(f"Testing with {len(sample_user_indices)} users: {sample_user_indices}")
print("\nPer-user recommendations:")
for user_idx in sample_user_indices:
    ind_feed = len(independent_feed_recs_sgd.get(user_idx, []))
    ind_video = len(independent_video_recs_sgd.get(user_idx, []))
    stack_feed = len(stackelberg_feed_recs_sgd.get(user_idx, []))
    stack_video = len(stackelberg_video_recs_sgd.get(user_idx, []))
    print(f"  User {user_idx}: Independent({ind_feed} feed, {ind_video} video) vs Stackelberg({stack_feed} feed, {stack_video} video)")

print("\n--- RESULTS COMPARISON ---")
print("=== SGD OPTIMIZATION ===")
print("--- Feed Page Metrics ---")
print(f"Independent SGD CTR: {independent_ctr_sgd:.4f}")
print(f"Stackelberg SGD CTR: {stackelberg_ctr_sgd:.4f}")
print(f"CTR Improvement (Stackelberg vs Independent): {stackelberg_ctr_sgd - independent_ctr_sgd:.4f}")
print(f"Independent SGD Recall@10: {independent_recall_sgd:.4f}")
print(f"Stackelberg SGD Recall@10: {stackelberg_recall_sgd:.4f}")
print(f"Recall@10 Improvement (Stackelberg vs Independent): {stackelberg_recall_sgd - independent_recall_sgd:.4f}")
print(f"Independent SGD NDCG@10: {independent_ndcg_sgd:.4f}")
print(f"Stackelberg SGD NDCG@10: {stackelberg_ndcg_sgd:.4f}")
print(f"NDCG@10 Improvement (Stackelberg vs Independent): {stackelberg_ndcg_sgd - independent_ndcg_sgd:.4f}")
print("--- Video Page Metrics ---")
print(f"Independent SGD Avg Videoplaytime: {independent_videotime_avg_sgd:.2f}")
print(f"Stackelberg SGD Avg Videoplaytime: {stackelberg_videotime_avg_sgd:.2f}")
print(f"Videoplaytime Improvement (Stackelberg vs Independent): {stackelberg_videotime_avg_sgd - independent_videotime_avg_sgd:.2f}")
print(f"Independent SGD Video Recall@5: {independent_video_recall_sgd:.4f}")
print(f"Stackelberg SGD Video Recall@5: {stackelberg_video_recall_sgd:.4f}")
print(f"Video Recall@5 Improvement (Stackelberg vs Independent): {stackelberg_video_recall_sgd - independent_video_recall_sgd:.4f}")
print(f"Independent SGD Video NDCG@5: {independent_video_ndcg_sgd:.4f}")
print(f"Stackelberg SGD Video NDCG@5: {stackelberg_video_ndcg_sgd:.4f}")
print(f"Video NDCG@5 Improvement (Stackelberg vs Independent): {stackelberg_video_ndcg_sgd - independent_video_ndcg_sgd:.4f}")

print("\n--- IMPROVEMENT SUMMARY ---")
improvements = []
if stackelberg_ctr_sgd > independent_ctr_sgd:
    improvements.append("✅ CTR")
else:
    improvements.append("❌ CTR")

if stackelberg_recall_sgd > independent_recall_sgd:
    improvements.append("✅ Feed Recall@10")
else:
    improvements.append("❌ Feed Recall@10")

if stackelberg_ndcg_sgd > independent_ndcg_sgd:
    improvements.append("✅ Feed NDCG@10")
else:
    improvements.append("❌ Feed NDCG@10")

if stackelberg_videotime_avg_sgd > independent_videotime_avg_sgd:
    improvements.append("✅ Videoplaytime")
else:
    improvements.append("❌ Videoplaytime")

if stackelberg_video_recall_sgd > independent_video_recall_sgd:
    improvements.append("✅ Video Recall@5")
else:
    improvements.append("❌ Video Recall@5")

if stackelberg_video_ndcg_sgd > independent_video_ndcg_sgd:
    improvements.append("✅ Video NDCG@5")
else:
    improvements.append("❌ Video NDCG@5")

print("Stackelberg vs Independent Performance:")
for improvement in improvements:
    print(f"  {improvement}")

total_improvements = len([x for x in improvements if "✅" in x])
print(f"\nOverall: {total_improvements}/6 metrics improved with Stackelberg")

if total_improvements == 6:
    print("🎯 SUCCESS: All metrics improved!")
elif total_improvements >= 4:
    print("✅ GOOD: Most metrics improved")
elif total_improvements >= 2:
    print("⚠️  PARTIAL: Some metrics improved")
else:
    print("❌ NEEDS WORK: Few metrics improved")

print(f"\n[INFO] SGD-only testing completed with {len(sample_user_indices)} users") 