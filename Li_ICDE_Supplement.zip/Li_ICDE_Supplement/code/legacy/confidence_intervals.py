import numpy as np
import pandas as pd
from typing import Dict, Callable

def bootstrap_metric(metric_func: Callable, recommendations: Dict, positive_pairs: set, 
                    n_bootstrap: int = 1000, confidence_level: float = 0.95, 
                    metric_name: str = "Metric", **kwargs) -> Dict:

    users = list(recommendations.keys())
    bootstrap_scores = []

    for i in range(n_bootstrap):
        if i % 100 == 0:
            print(f"  Progress: {i}/{n_bootstrap} bootstrap samples")
        

        bootstrap_users = np.random.choice(users, size=len(users), replace=True)
        

        bootstrap_recs = {user: recommendations[user] for user in bootstrap_users}

        try:
            score = metric_func(bootstrap_recs, positive_pairs, **kwargs)
            bootstrap_scores.append(score)
        except Exception as e:
            print(f"  Warning: Error in bootstrap sample {i}: {e}")
            continue
    
    bootstrap_scores = np.array(bootstrap_scores)
    mean_score = np.mean(bootstrap_scores)
    std_score = np.std(bootstrap_scores)

    alpha = 1 - confidence_level
    lower_percentile = (alpha/2) * 100
    upper_percentile = (1 - alpha/2) * 100
    
    ci_lower = np.percentile(bootstrap_scores, lower_percentile)
    ci_upper = np.percentile(bootstrap_scores, upper_percentile)
    
    print(f"  {metric_name} Bootstrap Results:")
    print(f"    Mean: {mean_score:.4f}")
    print(f"    Std: {std_score:.4f}")
    print(f"    {confidence_level*100}% CI: [{ci_lower:.4f}, {ci_upper:.4f}]")
    
    return {
        'metric_name': metric_name,
        'mean': mean_score,
        'std': std_score,
        'ci_lower': ci_lower,
        'ci_upper': ci_upper,
        'confidence_level': confidence_level,
        'n_bootstrap': n_bootstrap,
        'bootstrap_samples': bootstrap_scores
    }

def bootstrap_videotime_metric(recommendations: Dict, video_df: pd.DataFrame, 
                              n_bootstrap: int = 1000, confidence_level: float = 0.95) -> Dict:

    users = list(recommendations.keys())
    bootstrap_scores = []
    
    for i in range(n_bootstrap):
        if i % 100 == 0:
            print(f"  Progress: {i}/{n_bootstrap} bootstrap samples")
        
        bootstrap_users = np.random.choice(users, size=len(users), replace=True)
        bootstrap_recs = {user: recommendations[user] for user in bootstrap_users}
        
        total_times = {}
        for user_idx, note_list in bootstrap_recs.items():
            user_time = 0
            for note_idx in note_list:
                match = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == note_idx)]
                if not match.empty:
                    user_time += float(match['video_watch_time'].iloc[0])
            total_times[user_idx] = user_time
        
        if total_times:
            avg_time = np.mean(list(total_times.values()))
            bootstrap_scores.append(avg_time)
    
    bootstrap_scores = np.array(bootstrap_scores)
    mean_score = np.mean(bootstrap_scores)
    std_score = np.std(bootstrap_scores)

    alpha = 1 - confidence_level
    ci_lower = np.percentile(bootstrap_scores, (alpha/2) * 100)
    ci_upper = np.percentile(bootstrap_scores, (1 - alpha/2) * 100)
    
    print(f"  Average video_watch_time Bootstrap Results:")
    print(f"    Mean: {mean_score:.2f}")
    print(f"    Std: {std_score:.2f}")
    print(f"    {confidence_level*100}% CI: [{ci_lower:.2f}, {ci_upper:.2f}]")
    
    return {
        'metric_name': 'Average video_watch_time',
        'mean': mean_score,
        'std': std_score,
        'ci_lower': ci_lower,
        'ci_upper': ci_upper,
        'confidence_level': confidence_level,
        'n_bootstrap': n_bootstrap,
        'bootstrap_samples': bootstrap_scores
    }
