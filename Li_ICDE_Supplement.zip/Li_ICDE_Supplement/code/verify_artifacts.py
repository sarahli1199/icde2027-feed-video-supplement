"""Check the archived code without loading data or starting experiments.

This utility is new packaging/verification code, not a historical experiment.
Run with --runtime for small in-memory module checks. No dataset is generated.
"""
import argparse
import ast
import contextlib
import hashlib
import importlib.util
import io
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT / "code" / "legacy"


def defined_names(tree):
    names = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            names.update(t.id for t in node.targets if isinstance(t, ast.Name))
    return names


def load_module(name):
    spec = importlib.util.spec_from_file_location(name, LEGACY / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    lines = ["Artifact verification", "", "Scope: code checks only; no industrial experiment was run."]
    trees = {}
    errors = []
    for path in sorted(LEGACY.glob("*.py")):
        try:
            trees[path.stem] = ast.parse(path.read_text(encoding="utf-8"), filename=path.name)
        except SyntaxError as exc:
            errors.append(str(exc))
    lines.append("Python syntax: %s (%d files)" % ("PASS" if not errors else "FAIL", len(trees)))

    manifest = (ROOT / "docs" / "PROVENANCE.txt").read_text().splitlines()
    current = None
    verified = 0
    for line in manifest:
        if line.startswith("code/legacy/"):
            current = ROOT / line
        elif line.startswith("  SHA-256:"):
            expected = line.split(":", 1)[1].strip()
            actual = hashlib.sha256(current.read_bytes()).hexdigest()
            if expected != actual:
                errors.append("Hash mismatch: " + current.name)
            verified += 1
    lines.append("Snapshot hashes checked: %d" % verified)

    missing = []
    for name, tree in trees.items():
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module in trees:
                defined = defined_names(trees[node.module])
                for alias in node.names:
                    if alias.name not in defined:
                        missing.append("%s.py:%d imports absent %s.%s" %
                                       (name, node.lineno, node.module, alias.name))
    lines.extend(["", "Unresolved local imports in the unchanged snapshot:"] + missing)
    forbidden = {".csv", ".tsv", ".parquet", ".feather", ".npy", ".npz", ".pkl", ".pickle", ".pt", ".pth", ".xlsx", ".xls", ".jsonl"}
    data_files = [p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and p.suffix.lower() in forbidden]
    if data_files:
        errors.append("Unexpected data/checkpoint files: " + ", ".join(data_files))
    lines.append("Data/checkpoint-file scan: " + ("PASS (none)" if not data_files else "FAIL"))

    if args.runtime:
        import torch
        import pandas as pd
        import numpy as np
        torch.manual_seed(0)
        torch.set_num_threads(1)
        models = load_module("models")
        model = models.EnhancedMatrixFactorization(2, 3).eval()
        follower = models.EnhancedTimeModel(2, 3).eval()
        users = torch.tensor([0, 1])
        items = torch.tensor([0, 2])
        with torch.no_grad():
            outputs = [model(users, items, torch.zeros(2, 7)),
                       follower(users, items, historical_features=torch.zeros(2, 6)),
                       follower(users, items, context=items, historical_features=torch.zeros(2, 6))]
        assert all(x.shape == (2,) and bool(torch.isfinite(x).all()) for x in outputs)
        lines.append("Runtime model interfaces: PASS (Feed; Video with/without context, with historical features)")

        jev = load_module("jev_computation")
        # A unit-check fixture held only in memory; no dataset is read or written.
        fixture = pd.DataFrame({"journey_key": [(0, 1)], "user_idx": [0], "jev_score": [2.0]})
        with contextlib.redirect_stdout(io.StringIO()):
            jev.clear_jev_cache()
            matched = jev.compute_jev_plus({0: [1, 2]}, fixture)
            jev.clear_jev_cache()
            unmatched = jev.compute_jev_plus({0: [2]}, fixture)
        assert abs(matched - 1.0) < 1e-12
        lines.append("Legacy JEV matched-key branch: PASS (one matched entry divided by two recommendations)")
        lines.append("Legacy JEV zero-matched-key branch: %.6f; paper click-gated formula would be 0. This is a documented discrepancy, not a corrected result." % unmatched)
        lines.append("Runtime: Python %s; torch %s; pandas %s; numpy %s" %
                     (sys.version.split()[0], torch.__version__, pd.__version__, np.__version__))
    else:
        lines.append("Runtime module checks: not requested")
    lines.extend(["", "Full training, benchmark reproduction, confidence intervals, and online A/B results: NOT VERIFIED.",
                  "The unresolved imports and methodological discrepancies require author review."])
    if errors:
        lines.extend(["", "Packaging errors:"] + errors)
    text = "\n".join(lines) + "\n"
    print(text, end="")
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text)
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
