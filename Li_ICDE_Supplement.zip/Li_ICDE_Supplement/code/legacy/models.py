import torch
import torch.nn as nn
from torch.utils.data import Dataset


class EnhancedMatrixFactorization(nn.Module):
    def __init__(self, num_users, num_items, embedding_dim=20, historical_features=7):
        super(EnhancedMatrixFactorization, self).__init__()
        self.user_embeds = nn.Embedding(num_users, embedding_dim)
        self.item_embeds = nn.Embedding(num_items, embedding_dim)
        self.user_embeds.weight.data.uniform_(0, 0.05)
        self.item_embeds.weight.data.uniform_(0, 0.05)
        
        # Historical features processing
        self.historical_encoder = nn.Sequential(
            nn.Linear(historical_features, embedding_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(embedding_dim, embedding_dim)
        )
        
        # Final prediction layer
        self.prediction_layer = nn.Sequential(
            nn.Linear(embedding_dim * 3, embedding_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(embedding_dim, 1)
        )
    
    def forward(self, user, item, historical_features=None):
        u = self.user_embeds(user)
        i = self.item_embeds(item)
        
        if historical_features is not None:
            # Process historical features
            h = self.historical_encoder(historical_features)
            # Combine user, item, and historical embeddings
            combined = torch.cat([u, i, h], dim=1)
            return self.prediction_layer(combined).squeeze(-1)
        else:
            # Fallback to original behavior
            return (u * i).sum(1)


class EnhancedTimeModel(nn.Module):
    def __init__(self, num_users, num_items, embedding_dim=20, historical_features=6):
        super(EnhancedTimeModel, self).__init__()
        self.embedding_dim = embedding_dim
        self.user_embeds = nn.Embedding(num_users, embedding_dim)
        self.item_embeds = nn.Embedding(num_items, embedding_dim)
        self.context_embeds = nn.Embedding(num_items, embedding_dim)
        
        # Historical features processing
        self.historical_encoder = nn.Sequential(
            nn.Linear(historical_features, embedding_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(embedding_dim, embedding_dim)
        )
        
        # Adaptive prediction layers for different input sizes
        self.prediction_layer_with_context = nn.Sequential(
            nn.Linear(embedding_dim * 4, embedding_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(embedding_dim, 1)
        )
        
        self.prediction_layer_without_context = nn.Sequential(
            nn.Linear(embedding_dim * 3, embedding_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(embedding_dim, 1)
        )
    
    def forward(self, user, item, context=None, historical_features=None):
        u = self.user_embeds(user)
        i = self.item_embeds(item)
        
        if context is not None:
            c = self.context_embeds(context)
            
            if historical_features is not None:
                # Process historical features
                h = self.historical_encoder(historical_features)
                # Combine user, item, context, and historical embeddings
                combined = torch.cat([u, i, c, h], dim=1)
                return self.prediction_layer_with_context(combined).squeeze(-1)
            else:
                # Original behavior without historical features
                x = torch.cat([u, i, c], dim=1)
                return nn.Linear(self.embedding_dim * 3, 1)(x).squeeze(-1)
        else:
            if historical_features is not None:
                # Process historical features
                h = self.historical_encoder(historical_features)
                # Combine user, item, and historical embeddings
                combined = torch.cat([u, i, h], dim=1)
                return self.prediction_layer_without_context(combined).squeeze(-1)
            else:
                # Original behavior without historical features
                x = torch.cat([u, i], dim=1)
                return nn.Linear(self.embedding_dim * 2, 1)(x).squeeze(-1)

class EnhancedInteractionDataset(Dataset):
    def __init__(self, df, user_col, item_col, score_col, historical_cols=None):
        self.users = torch.tensor(df[user_col].values, dtype=torch.long)
        self.items = torch.tensor(df[item_col].values, dtype=torch.long)
        self.scores = torch.tensor(df[score_col].values, dtype=torch.float)
        
        # Historical features
        if historical_cols:
            self.historical_features = torch.tensor(df[historical_cols].values, dtype=torch.float)
        else:
            self.historical_features = None
    
    def __len__(self):
        return len(self.scores)
    
    def __getitem__(self, idx):
        if self.historical_features is not None:
            return self.users[idx], self.items[idx], self.scores[idx], self.historical_features[idx]
        else:
            return self.users[idx], self.items[idx], self.scores[idx]
