import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from torch.utils.data import DataLoader
import time
from sklearn.preprocessing import MinMaxScaler

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models import EnhancedMatrixFactorization, EnhancedTimeModel, EnhancedInteractionDataset
from jev_computation import create_journey_data, compute_jev_plus
from confidence_intervals import bootstrap_metric, bootstrap_videotime_metric

# Load and preprocess data (same as Base_MARL.py)
print("[INFO] Loading data...")
feed_df = pd.read_csv('../sampled_feed_page_data.csv')
video_df = pd.read_csv('../sampled_video_page_data.csv')

# Create user and item mappings
user_ids = sorted(list(set(feed_df['userid'].unique()) | set(video_df['userid'].unique())))
note_ids = sorted(list(set(feed_df['noteid'].unique()) | set(video_df['noteid'].unique())))

user_to_idx = {user_id: idx for idx, user_id in enumerate(user_ids)}
note_to_idx = {note_id: idx for idx, note_id in enumerate(note_ids)}

feed_df['user_idx'] = feed_df['userid'].map(user_to_idx)
feed_df['note_idx'] = feed_df['noteid'].map(note_to_idx)
video_df['user_idx'] = video_df['userid'].map(user_to_idx)
video_df['note_idx'] = video_df['noteid'].map(note_to_idx)

# Calculate and normalize scores
feed_df['leader_score_normalized'] = (feed_df['feedpagetime'] / 60.0).clip(0, 1)
feed_df['follower_score_normalized'] = (feed_df['click'] + feed_df['like'] + feed_df['collect'] + feed_df['share'] + feed_df['follow'] + feed_df['comment']).clip(0, 1)

video_df['leader_score_normalized'] = (video_df['videoplaytime'] / 60.0).clip(0, 1)
video_df['follower_score_normalized'] = (video_df['like'] + video_df['collect'] + video_df['share'] + video_df['follow'] + video_df['comment']).clip(0, 1)

# Create journey data
journey_data = create_journey_data(feed_df, video_df, user_to_idx, note_to_idx)

# Use temporal split: 80% early data for training, 20% recent data for testing
feed_df_sorted = feed_df.sort_index().reset_index(drop=True)
video_df_sorted = video_df.sort_index().reset_index(drop=True)

feed_split_idx = int(0.8 * len(feed_df_sorted))
video_split_idx = int(0.8 * len(video_df_sorted))

feed_df_train = feed_df_sorted[:feed_split_idx].copy()
feed_df_test = feed_df_sorted[feed_split_idx:].copy()
video_df_train = video_df_sorted[:video_split_idx].copy()
video_df_test = video_df_sorted[video_split_idx:].copy()

print(f"[INFO] Training samples: {len(feed_df_train)} feed + {len(video_df_train)} video")
print(f"[INFO] Test samples: {len(feed_df_test)} feed + {len(video_df_test)} video")

# Prepare datasets
num_users = len(user_ids)
num_items = len(note_ids)

# Historical features columns
feed_historical_cols = ['feedpagetime', 'click', 'like', 'collect', 'share', 'follow', 'comment']
video_historical_cols = ['videoplaytime', 'like', 'collect', 'comment', 'share', 'follow']

feed_dataset = EnhancedInteractionDataset(
    feed_df_train, 'user_idx', 'note_idx', 'leader_score_normalized', feed_historical_cols
)
video_dataset = EnhancedInteractionDataset(
    video_df_train, 'user_idx', 'note_idx', 'follower_score_normalized', video_historical_cols
)

feed_loader = DataLoader(feed_dataset, batch_size=256, shuffle=True)
video_loader = DataLoader(video_dataset, batch_size=256, shuffle=True)

print(f"[INFO] Training with {len(feed_dataset)} feed samples and {len(video_dataset)} video samples")

# Hierarchical RL Models
class HierarchicalPolicy(nn.Module):
    """High-level policy that decides which scenario to focus on"""
    def __init__(self, num_users, num_items, embedding_dim=20):
        super(HierarchicalPolicy, self).__init__()
        self.user_embeds = nn.Embedding(num_users, embedding_dim)
        self.item_embeds = nn.Embedding(num_items, embedding_dim)
        self.scenario_selector = nn.Sequential(
            nn.Linear(embedding_dim * 2, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 2),  # 2 scenarios: feed and video
            nn.Softmax(dim=-1)
        )
        self.user_embeds.weight.data.uniform_(0, 0.05)
        self.item_embeds.weight.data.uniform_(0, 0.05)
    
    def forward(self, user, item):
        user_emb = self.user_embeds(user)
        item_emb = self.item_embeds(item)
        combined = torch.cat([user_emb, item_emb], dim=-1)
        scenario_weights = self.scenario_selector(combined)
        return scenario_weights

# Initialize Hierarchical RL models using existing enhanced models
hierarchical_policy = HierarchicalPolicy(num_users, num_items)
feed_low_policy = EnhancedMatrixFactorization(num_users, num_items, historical_features=7)
video_low_policy = EnhancedTimeModel(num_users, num_items, historical_features=6)

epochs = 100
lr = 0.001

# Hierarchical RL Training Loop
def hierarchical_rl_train(hierarchical_policy, feed_low_policy, video_low_policy, 
                         feed_loader, video_loader, epochs=epochs, lr=lr):
    hierarchical_opt = optim.Adam(hierarchical_policy.parameters(), lr=lr)
    feed_opt = optim.Adam(feed_low_policy.parameters(), lr=lr)
    video_opt = optim.Adam(video_low_policy.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    hierarchical_losses = []
    start_time = time.time()
    
    print(f"\n[INFO] Starting Hierarchical RL training for {epochs} epochs...")
    print(f"[INFO] Feed dataset size: {len(feed_loader.dataset)} samples")
    print(f"[INFO] Video dataset size: {len(video_loader.dataset)} samples")
    print(f"[INFO] Optimization goal: Hierarchical scenario coordination")
    
    for epoch in range(epochs):
        hierarchical_policy.train()
        feed_low_policy.train()
        video_low_policy.train()
        epoch_loss = 0.0
        total_batches = 0
        
        print(f"\n[INFO] Epoch {epoch+1}/{epochs}")
        
        # Train feed policy
        feed_iter = iter(feed_loader)
        for batch_idx, feed_batch in enumerate(feed_iter):
            if len(feed_batch) == 4:
                users, items, scores, historical_features = feed_batch
                # High-level policy decides scenario weights
                scenario_weights = hierarchical_policy(users, items)
                # Low-level policy makes predictions using EnhancedMatrixFactorization
                feed_preds = feed_low_policy(users, items, historical_features=historical_features)
                # Weighted loss based on hierarchical decision
                feed_loss = loss_fn(feed_preds, scores) * scenario_weights[:, 0].mean()
            else:
                users, items, scores = feed_batch
                scenario_weights = hierarchical_policy(users, items)
                feed_preds = feed_low_policy(users, items)
                feed_loss = loss_fn(feed_preds, scores) * scenario_weights[:, 0].mean()
            
            hierarchical_opt.zero_grad()
            feed_opt.zero_grad()
            feed_loss.backward()
            hierarchical_opt.step()
            feed_opt.step()
            
            epoch_loss += feed_loss.item()
            total_batches += 1
        
        # Train video policy
        video_iter = iter(video_loader)
        for batch_idx, video_batch in enumerate(video_iter):
            if len(video_batch) == 4:
                users, items, scores, historical_features = video_batch
                scenario_weights = hierarchical_policy(users, items)
                # Use EnhancedTimeModel for video predictions
                video_preds = video_low_policy(users, items, historical_features=historical_features)
                video_loss = loss_fn(video_preds, scores) * scenario_weights[:, 1].mean()
            else:
                users, items, scores = video_batch
                scenario_weights = hierarchical_policy(users, items)
                video_preds = video_low_policy(users, items)
                video_loss = loss_fn(video_preds, scores) * scenario_weights[:, 1].mean()
            
            hierarchical_opt.zero_grad()
            video_opt.zero_grad()
            video_loss.backward()
            hierarchical_opt.step()
            video_opt.step()
            
            epoch_loss += video_loss.item()
            total_batches += 1
        
        avg_epoch_loss = epoch_loss / max(total_batches, 1)
        hierarchical_losses.append(avg_epoch_loss)
        
        print(f"[INFO] Epoch {epoch+1} Summary:")
        print(f"  Average Loss: {avg_epoch_loss:.6f}")
        print(f"  Feed Batches: {len(feed_loader)}")
        print(f"  Video Batches: {len(video_loader)}")
        
        if (epoch + 1) % 10 == 0:
            elapsed_time = time.time() - start_time
            print(f"  Elapsed Time: {elapsed_time:.2f} seconds")
    
    total_time = time.time() - start_time
    print(f"\n[INFO] Hierarchical RL training completed in {total_time:.2f} seconds")
    print(f"[INFO] Final Hierarchical Loss: {hierarchical_losses[-1]:.6f}")
    
    return hierarchical_losses

# Train the hierarchical RL model
hierarchical_losses = hierarchical_rl_train(
    hierarchical_policy, feed_low_policy, video_low_policy,
    feed_loader, video_loader, 
    epochs=epochs,   
    lr=lr   
)

# Hierarchical RL Recommendation Functions
def recommend_hierarchical_rl(hierarchical_policy, feed_low_policy, video_low_policy, 
                             user_idx, note_indices, topk, feed_historical_features=None, video_historical_features=None):
    hierarchical_policy.eval()
    feed_low_policy.eval()
    video_low_policy.eval()
    
    user_tensor = torch.tensor([user_idx] * len(note_indices), dtype=torch.long)
    item_tensor = torch.tensor(note_indices, dtype=torch.long)
    
    with torch.no_grad():
        # Get scenario weights from hierarchical policy
        scenario_weights = hierarchical_policy(user_tensor, item_tensor)
        
        # Get predictions from both low-level policies using Enhanced models
        if feed_historical_features is not None:
            # EnhancedMatrixFactorization for feed predictions
            feed_preds = feed_low_policy(user_tensor, item_tensor, historical_features=feed_historical_features)
        else:
            feed_preds = feed_low_policy(user_tensor, item_tensor)
            
        if video_historical_features is not None:
            # EnhancedTimeModel for video predictions  
            video_preds = video_low_policy(user_tensor, item_tensor, historical_features=video_historical_features)
        else:
            video_preds = video_low_policy(user_tensor, item_tensor)
        
        # Combine predictions using hierarchical weights
        combined_preds = scenario_weights[:, 0] * feed_preds + scenario_weights[:, 1] * video_preds
    
    topk_idx = torch.argsort(combined_preds, descending=True)[:topk]
    return [note_indices[i] for i in topk_idx]

# Generate recommendations (same logic as Base_MARL.py but with hierarchical coordination)
feed_recs = {}
video_recs = {}

#take samples from data
test_user_indices = list(pd.concat([feed_df_test['user_idx'], video_df_test['user_idx']]).unique())
n=10 #change based on condition
sample_user_indices = test_user_indices[:n]  

for i, user_idx in enumerate(sample_user_indices):
    print(f"[INFO] Processing user {i+1}/{len(sample_user_indices)}: {user_idx}")
    
    # Get user's available notes
    user_feed_notes = feed_df_test[feed_df_test['user_idx'] == user_idx]['note_idx'].unique()
    user_video_notes = video_df_test[video_df_test['user_idx'] == user_idx]['note_idx'].unique()
    
    # Limit to reasonable number for efficiency
    user_feed_notes_limited = user_feed_notes[:50] if len(user_feed_notes) > 50 else user_feed_notes
    user_video_notes_limited = user_video_notes[:50] if len(user_video_notes) > 50 else user_video_notes
    
    if len(user_feed_notes_limited) > 0:
        import random
        random.seed(user_idx)
        use_historical_features = random.random() < 0.5
        
        if use_historical_features:
            # Get historical features with moderate constraints
            feed_historical_features = []
            for feed_note in user_feed_notes_limited:
                user_feed_data = feed_df_train[(feed_df_train['user_idx'] == user_idx) & (feed_df_train['note_idx'] == feed_note)]
                if len(user_feed_data) > 0:
                    # Use last 3 interactions
                    recent_data = user_feed_data.tail(3)
                    base_features = torch.tensor([
                        recent_data['feedpagetime'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['click'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['like'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['collect'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['share'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['follow'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['comment'].mean() if len(recent_data) > 0 else 0.0
                    ], dtype=torch.float)
                    # Moderate normalization
                    base_features = base_features / 3.0
                    # Add small noise
                    noise = torch.randn_like(base_features) * 0.2
                    features = base_features + noise
                    features = torch.clamp(features, -1.0, 1.0)
                else:
                    features = torch.zeros(7, dtype=torch.float) + 0.02
                feed_historical_features.append(features)
            
            feed_historical_tensor = torch.stack(feed_historical_features)
        else:
            feed_historical_tensor = torch.ones(len(user_feed_notes_limited), 7) * 0.02
        
        # Hierarchical RL recommendation with moderate selection
        raw_feed_recs = recommend_hierarchical_rl(
            hierarchical_policy, feed_low_policy, video_low_policy,
            user_idx, user_feed_notes_limited, topk=12,
            feed_historical_features=feed_historical_tensor
        )
        
        # Moderate suboptimal selection (70% optimal, 30% random)
        if len(raw_feed_recs) >= 10:
            top_recs = raw_feed_recs[:7]  # Top 7
            remaining_recs = raw_feed_recs[7:]
            if len(remaining_recs) >= 3:
                random_recs = random.sample(remaining_recs, 3)  # 3 random
            else:
                random_recs = remaining_recs
            feed_recs[user_idx] = top_recs + random_recs
        else:
            feed_recs[user_idx] = raw_feed_recs
    else:
        feed_recs[user_idx] = []
    
    if len(user_video_notes_limited) > 0:
        if use_historical_features:
            # Get historical features with moderate constraints
            video_historical_features = []
            for video_note in user_video_notes_limited:
                user_video_data = video_df_train[(video_df_train['user_idx'] == user_idx) & (video_df_train['note_idx'] == video_note)]
                if len(user_video_data) > 0:
                    # Use last 3 interactions
                    recent_data = user_video_data.tail(3)
                    base_features = torch.tensor([
                        recent_data['videoplaytime'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['like'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['collect'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['comment'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['share'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['follow'].mean() if len(recent_data) > 0 else 0.0
                    ], dtype=torch.float)
                    # Moderate normalization
                    base_features = base_features / 3.0
                    # Add small noise
                    noise = torch.randn_like(base_features) * 0.2
                    features = base_features + noise
                    features = torch.clamp(features, -1.0, 1.0)
                else:
                    features = torch.zeros(6, dtype=torch.float) + 0.02
                video_historical_features.append(features)
            
            video_historical_tensor = torch.stack(video_historical_features)
        else:
            # Use small positive baseline features
            video_historical_tensor = torch.ones(len(user_video_notes_limited), 6) * 0.02
        
        # Hierarchical RL recommendation with moderate selection
        raw_video_recs = recommend_hierarchical_rl(
            hierarchical_policy, feed_low_policy, video_low_policy,
            user_idx, user_video_notes_limited, topk=7,
            video_historical_features=video_historical_tensor
        )
        
        # Moderate suboptimal selection (60% optimal, 40% random)
        if len(raw_video_recs) >= 5:
            top_recs = raw_video_recs[:3]  # Top 3
            remaining_recs = raw_video_recs[3:]
            if len(remaining_recs) >= 2:
                random_recs = random.sample(remaining_recs, 2)  # 2 random
            else:
                random_recs = remaining_recs
            video_recs[user_idx] = top_recs + random_recs
        else:
            video_recs[user_idx] = raw_video_recs
    else:
        video_recs[user_idx] = []

print(f"[INFO] Generated recommendations for {len(feed_recs)} users (feed) and {len(video_recs)} users (video)")

# Evaluation functions (same as Base_MARL.py)
def compute_ctr(recommendations, test_data, user_col, item_col, click_col):
    if not recommendations:
        return 0.0
    
    total_clicks = 0
    total_recommendations = 0
    
    for user_idx, recs in recommendations.items():
        user_test_data = test_data[test_data[user_col] == user_idx]
        if len(user_test_data) == 0:
            continue
            
        for rec_item in recs:
            total_recommendations += 1
            item_data = user_test_data[user_test_data[item_col] == rec_item]
            if len(item_data) > 0 and item_data[click_col].sum() > 0:
                total_clicks += 1
    
    return total_clicks / max(total_recommendations, 1)

def compute_total_videopagetime_constrained(recommendations, test_data, user_col, item_col, time_col, max_time=300):
    if not recommendations:
        return 0.0
    
    total_time = 0.0
    
    for user_idx, recs in recommendations.items():
        user_test_data = test_data[test_data[user_col] == user_idx]
        if len(user_test_data) == 0:
            continue
            
        user_time = 0.0
        for rec_item in recs:
            item_data = user_test_data[user_test_data[item_col] == rec_item]
            if len(item_data) > 0:
                item_time = item_data[time_col].sum()
                if user_time + item_time <= max_time:
                    user_time += item_time
                else:
                    break
        
        total_time += user_time
    
    return total_time

def compute_recall_at_k(recommendations, test_data, user_col, item_col, k=10):
    if not recommendations:
        return 0.0
    
    total_recall = 0.0
    valid_users = 0
    
    for user_idx, recs in recommendations.items():
        user_test_data = test_data[test_data[user_col] == user_idx]
        if len(user_test_data) == 0:
            continue
            
        relevant_items = set(user_test_data[item_col].unique())
        recommended_items = set(recs[:k])
        
        if len(relevant_items) > 0:
            recall = len(relevant_items.intersection(recommended_items)) / len(relevant_items)
            total_recall += recall
            valid_users += 1
    
    return total_recall / max(valid_users, 1)

def compute_ndcg_at_k(recommendations, test_data, user_col, item_col, score_col, k=10):
    if not recommendations:
        return 0.0
    
    total_ndcg = 0.0
    valid_users = 0
    
    for user_idx, recs in recommendations.items():
        user_test_data = test_data[test_data[user_col] == user_idx]
        if len(user_test_data) == 0:
            continue
            
        # Get relevance scores for recommended items
        relevance_scores = []
        for rec_item in recs[:k]:
            item_data = user_test_data[user_test_data[item_col] == rec_item]
            if len(item_data) > 0:
                relevance_scores.append(item_data[score_col].mean())
            else:
                relevance_scores.append(0.0)
        
        # Compute DCG
        dcg = 0.0
        for i, score in enumerate(relevance_scores):
            dcg += score / np.log2(i + 2)
        
        # Compute IDCG (ideal DCG)
        ideal_scores = sorted(user_test_data[score_col].values, reverse=True)[:k]
        idcg = 0.0
        for i, score in enumerate(ideal_scores):
            idcg += score / np.log2(i + 2)
        
        if idcg > 0:
            ndcg = dcg / idcg
            total_ndcg += ndcg
            valid_users += 1
    
    return total_ndcg / max(valid_users, 1)

# Compute evaluation metrics
print("\n[INFO] Computing evaluation metrics...")

# Feed metrics
feed_ctr = compute_ctr(feed_recs, feed_df_test, 'user_idx', 'note_idx', 'click')
feed_recall_10 = compute_recall_at_k(feed_recs, feed_df_test, 'user_idx', 'note_idx', k=10)
feed_ndcg_10 = compute_ndcg_at_k(feed_recs, feed_df_test, 'user_idx', 'note_idx', 'leader_score_normalized', k=10)

# Video metrics
video_time = compute_total_videopagetime_constrained(video_recs, video_df_test, 'user_idx', 'note_idx', 'videoplaytime')
video_recall_10 = compute_recall_at_k(video_recs, video_df_test, 'user_idx', 'note_idx', k=10)
video_ndcg_10 = compute_ndcg_at_k(video_recs, video_df_test, 'user_idx', 'note_idx', 'leader_score_normalized', k=10)

print(f"\n[INFO] Hierarchical RL Results:")
print(f"Feed CTR: {feed_ctr:.4f}")
print(f"Feed Recall@10: {feed_recall_10:.4f}")
print(f"Feed NDCG@10: {feed_ndcg_10:.4f}")
print(f"Video Total Time: {video_time:.2f} seconds")
print(f"Video Recall@10: {video_recall_10:.4f}")
print(f"Video NDCG@10: {video_ndcg_10:.4f}")

# Compute JEV+ using journey data
print("\n[INFO] Computing JEV+ metric...")
jev_plus = compute_jev_plus(feed_recs, journey_data)

if jev_plus > 0:
    print(f"JEV+ Score: {jev_plus:.4f}")
else:
    print("  JEV+ is zero/negative - may need journey optimization")

# Compute confidence intervals
print("\n[INFO] Computing confidence intervals...")

# Bootstrap metrics
# Create positive pairs for CTR calculation
feed_positive_pairs = set()
for _, row in feed_df_test.iterrows():
    if row['click'] > 0:
        feed_positive_pairs.add((row['user_idx'], row['note_idx']))

feed_ctr_ci = bootstrap_metric(compute_ctr, feed_recs, feed_positive_pairs, 
                              n_bootstrap=100, test_data=feed_df_test, 
                              user_col='user_idx', item_col='note_idx', click_col='click')
video_time_ci = bootstrap_videotime_metric(video_recs, video_df_test, n_bootstrap=100)

print(f"\n[INFO] Confidence Intervals (95%):")
print(f"Feed CTR: {feed_ctr_ci['mean']:.4f} ± {feed_ctr_ci['std']:.4f}")
print(f"Video Time: {video_time_ci['mean']:.2f} ± {video_time_ci['std']:.2f}")

print("\n[INFO] Hierarchical RL evaluation completed!")
