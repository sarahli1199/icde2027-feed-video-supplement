import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Data extracted from your LaTeX table
data = {
    'Configuration': [' + Contextual Follower', ' + Follower-Aware Leader', ' + Historical Features (Full)'],
    'Delta_CTR': [0.00, 26.56, 27.66],  # Removed baseline
    'Delta_Rec@10': [12.11, 10.36, 11.12], # Removed baseline
    'Delta_Time': [1.54, 1.09, 2.70] # Removed baseline
}

df = pd.DataFrame(data)

# Now, we will include the baseline row in plot_df
plot_df = df.copy()

# Define the metrics to plot
metrics = ['Delta_CTR', 'Delta_Rec@10', 'Delta_Time']
metric_labels = ['$\Delta$ CTR (%)', '$\Delta$ Rec@10 (%)', '$\Delta$ Time (%)']
colors = ['#4A7C9B', '#E88D54', '#5FAD56'] # No color, color, no color
patterns = ['/', 'none', 'none'] # Lines only, no pattern, no pattern
markers = ['o', 's', '^'] # Distinct markers for each metric

# Set up the plot with Times New Roman font
plt.rcParams['font.family'] = 'Times New Roman'
fig, ax = plt.subplots(figsize=(16, 10))

# Number of configurations and metrics
n_configs = len(plot_df)
n_metrics = len(metrics)

# Set up bar positions
x = np.arange(n_configs)
width = 0.25  # Width of bars

# Create grouped bar chart
for i, metric in enumerate(metrics):
    if colors[i] == 'none':
        # No color, just edge
        bars = ax.bar(x + i * width, plot_df[metric], width, 
                      label=metric_labels[i], color='white', alpha=1.0, edgecolor='black', linewidth=1.5)
    else:
        # With color
        bars = ax.bar(x + i * width, plot_df[metric], width, 
                      label=metric_labels[i], color=colors[i], alpha=0.8, edgecolor='black', linewidth=1.0)
    
    # Add line patterns to bars (only for first metric)
    if patterns[i] != 'none':
        for bar in bars:
            bar.set_hatch(patterns[i])
    
    # Add value labels on top of bars
    for j, bar in enumerate(bars):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}%',
                ha='center', va='bottom' if height >= 0 else 'top',
                fontsize=28, fontweight='bold')

# Add labels, title, and legend
ax.set_xlabel('Configuration', fontsize=36)
ax.set_ylabel('Percentage Improvement (%)', fontsize=36)
ax.set_title('Ablation Study: Cumulative Percentage Improvement of Model Components', fontsize=38)
ax.set_xticks(x + width)
ax.set_xticklabels(plot_df['Configuration'], rotation=0, ha='center', fontsize=34)
ax.legend(fontsize=34)
ax.grid(axis='y', linestyle='--', alpha=0.3, color='gray', zorder=0) # zorder to ensure grid is behind points

# Adjust layout to prevent labels from being cut off
plt.tight_layout()

# Save the plot
plt.savefig('ablation.png', dpi=300, bbox_inches='tight')
