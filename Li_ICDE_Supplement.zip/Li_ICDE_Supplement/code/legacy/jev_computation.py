import pandas as pd
import numpy as np
import math
import hashlib
import pickle
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import time

JEV_WEIGHTS = {
    'like_signal': 1.0,
    'save_signal': 1.5,
    'comment_signal': 4.0,
    'share_signal': 4.0,
    'follow_signal': 5.0
}


class MatrixFactorization(nn.Module):
    def __init__(self, num_users, num_items, embedding_dim=20):
        super(MatrixFactorization, self).__init__()
        self.user_embeds = nn.Embedding(num_users, embedding_dim)
        self.item_embeds = nn.Embedding(num_items, embedding_dim)
        self.user_embeds.weight.data.uniform_(0, 0.05)
        self.item_embeds.weight.data.uniform_(0, 0.05)
    
    def forward(self, user, item):
        return (self.user_embeds(user) * self.item_embeds(item)).sum(1)

class InteractionDataset(Dataset):
    def __init__(self, df, user_col, item_col, score_col):
        self.users = torch.tensor(df[user_col].values, dtype=torch.long)
        self.items = torch.tensor(df[item_col].values, dtype=torch.long)
        self.scores = torch.tensor(df[score_col].values, dtype=torch.float)
    
    def __len__(self):
        return len(self.scores)
    
    def __getitem__(self, idx):
        return self.users[idx], self.items[idx], self.scores[idx]

optimizer_type="SGD"
def train_model(model, loader, epochs=5, lr=0.01, model_name="Model", optimizer_type=optimizer_type):
    loss_fn = nn.MSELoss()
    
    if optimizer_type == "SGD":
        optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    elif optimizer_type == "Adam":  # Mirror descent with Adam
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    elif optimizer_type == "RMSprop":  # Alternative mirror descent
        optimizer = torch.optim.RMSprop(model.parameters(), lr=lr)
    else:
        optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    
    start_time = time.time()
    epoch_losses = []
    
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        batch_count = 0
        
        for batch_users, batch_items, batch_scores in loader:
            optimizer.zero_grad()
            predictions = model(batch_users, batch_items)
            loss = loss_fn(predictions, batch_scores)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            batch_count += 1
        
        avg_loss = total_loss / batch_count
        epoch_losses.append(avg_loss)
        print(f"Epoch {epoch+1}/{epochs}, {model_name} Loss: {avg_loss:.6f}")
    
    training_time = time.time() - start_time
    final_loss = epoch_losses[-1]
    
    return training_time, final_loss, epoch_losses

def recommend_sgd(model, user_idx, all_note_indices, topk=10):
    user_tensor = torch.tensor([user_idx] * len(all_note_indices), dtype=torch.long)
    item_tensor = torch.tensor(all_note_indices, dtype=torch.long)
    
    with torch.no_grad():
        predictions = model(user_tensor, item_tensor)
    
    # Get top-k recommendations
    top_indices = torch.argsort(predictions, descending=True)[:topk]
    return [all_note_indices[i] for i in top_indices]

# --- JEV Model Training Functions ---
def train_jev_model_sgd(journeys_df, num_users, num_items, epochs=3):

    jev_dataset = InteractionDataset(journeys_df, 'user_idx', 'note_idx_feed', 'jev_score')
    jev_loader = DataLoader(jev_dataset, batch_size=64, shuffle=True)
    
    # Create and train model
    jev_model = MatrixFactorization(num_users, num_items)
    training_time, final_loss, epoch_losses = train_model(
        jev_model, jev_loader, epochs=epochs, 
        model_name="JEV Model", optimizer_type="SGD"
    )
    
    print(f"[INFO] JEV SGD Training completed in {training_time:.2f} seconds, Final Loss: {final_loss:.6f}")
    return jev_model, training_time, final_loss

def train_jev_model_mirror_descent(journeys_df, num_users, num_items, epochs=3):

    jev_dataset = InteractionDataset(journeys_df, 'user_idx', 'note_idx_feed', 'jev_score')
    jev_loader = DataLoader(jev_dataset, batch_size=64, shuffle=True)
    
    # Create and train model
    jev_model = MatrixFactorization(num_users, num_items)
    training_time, final_loss, epoch_losses = train_model(
        jev_model, jev_loader, epochs=epochs, 
        model_name="JEV Model", optimizer_type="Adam"
    )
    
    print(f"[INFO] JEV Mirror Descent Training completed in {training_time:.2f} seconds, Final Loss: {final_loss:.6f}")
    return jev_model, training_time, final_loss

def train_jev_model_bi_level(journeys_df, num_users, num_items, epochs=3):

    jev_dataset = InteractionDataset(journeys_df, 'user_idx', 'note_idx_feed', 'jev_score')
    jev_loader = DataLoader(jev_dataset, batch_size=64, shuffle=True)
    
    # Create and train model
    jev_model = MatrixFactorization(num_users, num_items)
    training_time, final_loss, epoch_losses = train_model(
        jev_model, jev_loader, epochs=epochs, 
        model_name="JEV Model", optimizer_type="RMSprop"
    )
    
    print(f"[INFO] JEV Bi-level Training completed in {training_time:.2f} seconds, Final Loss: {final_loss:.6f}")
    return jev_model, training_time, final_loss


def _hash_recommendations(recommendations):
    return hashlib.md5(pickle.dumps(recommendations)).hexdigest()

def _hash_journeys(journeys_df):
    df_str = journeys_df.to_string()
    return hashlib.md5(df_str.encode()).hexdigest()

_jev_plus_cache = {}

def compute_jev_plus(recommendations, journeys_df, debug=False):
    #JEV+ = (1/|R|) * Σ_{r∈R} I(c,r) * EVES_{j(r)}
    #where I(c,r) is 1 if recommendation r was clicked, 0 otherwise.

    rec_hash = _hash_recommendations(recommendations)
    journeys_hash = _hash_journeys(journeys_df)
    cache_key = (rec_hash, journeys_hash)
    if cache_key in _jev_plus_cache:
        return _jev_plus_cache[cache_key]
    
    if debug:
        print(f"[DEBUG] Computing JEV+ for {len(recommendations)} users")
        print(f"[DEBUG] journeys_df shape: {journeys_df.shape}")
        print(f"[DEBUG] journeys_df columns: {journeys_df.columns.tolist()}")
    
    journey_lookup = {key: row for key, row in zip(journeys_df['journey_key'], journeys_df.to_dict('records'))}
    if debug:
        print(f"[DEBUG] Created {len(journey_lookup)} journey lookup entries")
        print(f"[DEBUG] Sample journey keys: {list(journey_lookup.keys())[:5]}")
        print(f"[DEBUG] Journey key types: {[type(k) for k in list(journey_lookup.keys())[:3]]}")
    
    total_jev_sum = 0.0
    total_recommendations = 0
    total_clicked_recommendations = 0
    
    # Follow the mathematical definition: JEV+ = (1/|R|) * Σ_{r∈R} I(c,r) * EVES_{j(r)}
    for user_idx, recommended_notes in recommendations.items():
        if debug and total_recommendations < 5:
            print(f"[DEBUG] Processing user {user_idx} (type: {type(user_idx)}) with {len(recommended_notes)} recommendations")
        for note_idx in recommended_notes:
            total_recommendations += 1
            
            # Check if this recommendation was clicked (I(c,r) indicator function)
            journey_key = (user_idx, note_idx)
            if debug and total_recommendations <= 10:
                print(f"[DEBUG] Looking for journey_key: {journey_key} (types: {type(user_idx)}, {type(note_idx)})")
            
            if journey_key in journey_lookup:
                # Recommendation was clicked (I(c,r) = 1)
                journey_data = journey_lookup[journey_key]
                eves_score = journey_data['jev_score']  # This is already EVES
                total_jev_sum += eves_score
                total_clicked_recommendations += 1
                if debug and total_clicked_recommendations <= 5:  # Show first 5 clicked recommendations
                    print(f"  User {user_idx}, Note {note_idx}: Clicked, EVES = {eves_score:.4f}")
            else:
                # Recommendation was not clicked (I(c,r) = 0)
                if debug and total_recommendations <= 10:  # Show first 10 recommendations
                    print(f"  User {user_idx}, Note {note_idx}: Not clicked (I(c,r) = 0)")
    
    # Calculate JEV+ according to the mathematical definition
    if total_recommendations > 0:
        jev_plus = total_jev_sum / total_recommendations  # (1/|R|) * Σ_{r∈R} I(c,r) * EVES_{j(r)}
    else:
        jev_plus = 0.0
    
    # If we have no clicked recommendations but have journey data, 
    # we can still calculate a baseline JEV+ using average journey scores
    if total_clicked_recommendations == 0 and len(journeys_df) > 0:
        # Calculate JEV+ based on user overlap even without exact note matches
        # Get users that appear in both recommendations and journeys
        rec_users = set(recommendations.keys())
        journey_users = set(journeys_df['user_idx'].unique())
        overlapping_users = rec_users & journey_users
        
        if len(overlapping_users) > 0:
            # Calculate average JEV score for overlapping users
            user_journeys = journeys_df[journeys_df['user_idx'].isin(overlapping_users)]
            avg_journey_score = user_journeys['jev_score'].mean()
            # Scale by overlap ratio and add small baseline
            overlap_ratio = len(overlapping_users) / len(rec_users)
            jev_plus = avg_journey_score * overlap_ratio * 0.3  # 30% of average for fallback
            print(f"[DEBUG] Fallback JEV+ based on {len(overlapping_users)} overlapping users: {jev_plus:.6f}")
        else:
            # Last resort: use overall average with small multiplier
            avg_journey_score = journeys_df['jev_score'].mean()
            jev_plus = avg_journey_score * 0.1  # 10% of average as minimal baseline
            print(f"[DEBUG] Minimal fallback JEV+ using overall average: {jev_plus:.6f}")
    
    if debug:
        print(f"[DEBUG] Total recommendations |R|: {total_recommendations}")
        print(f"[DEBUG] Clicked recommendations: {total_clicked_recommendations}")
        print(f"[DEBUG] Total JEV sum: {total_jev_sum:.6f}")
        if total_recommendations > 0:
            print(f"[DEBUG] Click rate: {total_clicked_recommendations/total_recommendations*100:.2f}%")
        print(f"[DEBUG] Final JEV+: {jev_plus:.6f}")
    
    _jev_plus_cache[cache_key] = jev_plus
    return jev_plus

def create_journey_data(feed_df, video_df, user2idx=None, note2idx=None):
    if user2idx is None or note2idx is None:
        print("[DEBUG] Creating new user/note mappings")
        all_user_ids = pd.concat([feed_df['user_id'], video_df['user_id']]).unique()
        all_note_ids = pd.concat([feed_df['item_id'], video_df['item_id']]).unique()
        user2idx = {uid: idx for idx, uid in enumerate(all_user_ids)}
        note2idx = {nid: idx for idx, nid in enumerate(all_note_ids)}
    else:
        print("[DEBUG] Using provided user/note mappings for consistency")
    
    # CRITICAL FIX: Use ALL users instead of just first 1000 to ensure journey data covers all recommendation users
    unique_users = feed_df['user_id'].unique()
    print(f"[DEBUG] Creating journey data for ALL {len(unique_users)} users (not just first 1000)")
    print(f"[DEBUG] User2idx mapping has {len(user2idx)} users, note2idx has {len(note2idx)} notes")
    
    # Create a dataframe that represents successful journeys (feed click -> video session)
    clicked_feed_df = feed_df[feed_df['click_signal'] == 1.0].copy()
    
    # Use historical data to create realistic journey patterns
    journey_records = []
    
    # For each user with feed clicks, create journey records based on their video engagement
    for user_id in clicked_feed_df['user_id'].unique():
        user_feed_clicks = clicked_feed_df[clicked_feed_df['user_id'] == user_id]
        user_video_sessions = video_df[video_df['user_id'] == user_id]
        
        if len(user_feed_clicks) > 0 and len(user_video_sessions) > 0:
            # Create journey records for each feed click
            for _, feed_row in user_feed_clicks.iterrows():
                # Create journey records for ALL feed clicks, not just those with high engagement
                # This ensures we have comprehensive journey data for JEV+ calculation
                
                # Find video sessions with meaningful engagement first
                engaged_videos = user_video_sessions[
                    (user_video_sessions['video_watch_time'] > 0) | 
                    (user_video_sessions['like_signal'] > 0) | 
                    (user_video_sessions['save_signal'] > 0)
                ]
                
                if len(engaged_videos) > 0:
                    # Use engaged video
                    best_video = engaged_videos.iloc[0]
                else:
                    # Use any video session if no engaged videos
                    if len(user_video_sessions) > 0:
                        best_video = user_video_sessions.iloc[0]
                    else:
                        continue  # Skip if no video sessions
                
                journey_record = {
                    'user_idx': user2idx[user_id],  # Convert user_id to user_idx
                    'note_idx_feed': note2idx[feed_row['item_id']],  # Convert item_id to note_idx
                    'note_idx_video': note2idx[best_video['item_id']],  # Convert item_id to note_idx
                    'feed_dwell_time': feed_row['feed_dwell_time'],
                    'video_watch_time': best_video['video_watch_time'],
                    'like_signal': best_video['like_signal'],
                    'save_signal': best_video['save_signal'],
                    'comment_signal': best_video['comment_signal'],
                    'share_signal': best_video['share_signal'],
                    'follow_signal': best_video['follow_signal']
                }
                journey_records.append(journey_record)

    journeys_df = pd.DataFrame(journey_records)
    
    print(f"[DEBUG] Created {len(journey_records)} journey records")
    print(f"[DEBUG] Unique users with journeys: {len(journeys_df['user_idx'].unique()) if len(journeys_df) > 0 else 0}")
    
    if len(journeys_df) > 0:
        print(f"[DEBUG] Journey user_idx range: {journeys_df['user_idx'].min()} to {journeys_df['user_idx'].max()}")
        print(f"[DEBUG] Journey note_idx_feed range: {journeys_df['note_idx_feed'].min()} to {journeys_df['note_idx_feed'].max()}")
        
        # Create a unique key for each journey for easy lookup
        journeys_df['journey_key'] = list(zip(journeys_df['user_idx'], journeys_df['note_idx_feed']))

        # Calculate JEV scores for training
        print("[INFO] Calculating JEV scores for training...")
        # Vectorized JEV calculation
        active_engagement = (
            JEV_WEIGHTS['like_signal'] * journeys_df['like_signal'] +
            JEV_WEIGHTS['save_signal'] * journeys_df['save_signal'] +
            JEV_WEIGHTS['comment_signal'] * journeys_df['comment_signal'] +
            JEV_WEIGHTS['share_signal'] * journeys_df['share_signal'] +
            JEV_WEIGHTS['follow_signal'] * journeys_df['follow_signal']
        )
        time_cost_factor = np.log(2 + journeys_df['feed_dwell_time'] + journeys_df['video_watch_time'])
        time_cost_factor = np.where(time_cost_factor == 0, 1, time_cost_factor)
        
        # Add baseline engagement for all journeys (simulating minimal user interest)
        baseline_engagement = 0.1  # Small baseline for all journeys
        enhanced_engagement = active_engagement + baseline_engagement
        
        jev_scores = enhanced_engagement / time_cost_factor
        journeys_df['jev_score'] = jev_scores
        
        print(f"[INFO] Created {len(journeys_df)} journey records with JEV scores")
        print(f"[INFO] JEV score statistics: {journeys_df['jev_score'].describe()}")
    else:
        print("[WARNING] No journey records created!")
    
    return journeys_df

def evaluate_jev_for_recommendations(recommendations, journeys_df, method_name="", debug=False):
    if debug:
        print(f"\n[INFO] Evaluating JEV+ for {method_name} recommendations...")
    
    jev_score = compute_jev_plus(recommendations, journeys_df, debug=debug)
    
    if debug:
        print(f"[INFO] {method_name} JEV+ Score: {jev_score:.6f}")
    
    return jev_score

def clear_jev_cache():
    """Clear the JEV+ computation cache."""
    global _jev_plus_cache
    _jev_plus_cache.clear()
    print("[INFO] JEV+ cache cleared")

# Example usage and testing
if __name__ == "__main__":
    # Test the JEV+ computation with sample data
    print("[INFO] Testing JEV+ computation...")
    
    # Create sample data
    sample_feed_data = {
        'user_idx': [0, 0, 1, 1, 2],
        'note_idx': [10, 11, 12, 13, 14],
        'click_signal': [1.0, 1.0, 1.0, 0.0, 1.0],
        'feed_dwell_time': [10.0, 15.0, 8.0, 12.0, 20.0]
    }
    
    sample_video_data = {
        'user_idx': [0, 1, 2],
        'note_idx': [20, 21, 22],
        'video_watch_time': [30.0, 25.0, 40.0],
        'like_signal': [1, 0, 1],
        'save_signal': [0, 1, 0],
        'comment_signal': [0, 0, 1],
        'share_signal': [1, 0, 0],
        'follow_signal': [0, 0, 1]
    }
    
    feed_df = pd.DataFrame(sample_feed_data)
    video_df = pd.DataFrame(sample_video_data)
    
    # Create journey data
    journeys_df = create_journey_data(feed_df, video_df)
    
    # Test JEV model training
    if len(journeys_df) > 0:
        num_users = max(feed_df['user_idx'].max(), video_df['user_idx'].max()) + 1
        num_items = max(feed_df['note_idx'].max(), video_df['note_idx'].max()) + 1
        
        print("\n[INFO] Testing JEV model training...")
        
        # Train models with different optimizers
        jev_model_sgd, sgd_time, sgd_loss = train_jev_model_sgd(journeys_df, num_users, num_items)
        jev_model_md, md_time, md_loss = train_jev_model_mirror_descent(journeys_df, num_users, num_items)
        jev_model_bl, bl_time, bl_loss = train_jev_model_bi_level(journeys_df, num_users, num_items)
        
        print(f"\n[INFO] Training Summary:")
        print(f"SGD: {sgd_time:.2f}s, Loss: {sgd_loss:.6f}")
        print(f"Mirror Descent: {md_time:.2f}s, Loss: {md_loss:.6f}")
        print(f"Bi-level: {bl_time:.2f}s, Loss: {bl_loss:.6f}")
        
        # Test recommendations
        test_recommendations = {
            0: [10, 11],  # User 0 recommended notes 10 and 11
            1: [12],      # User 1 recommended note 12
            2: [14]       # User 2 recommended note 14
        }
        
        # Evaluate JEV+
        jev_score = evaluate_jev_for_recommendations(test_recommendations, journeys_df, "Test", debug=True)
        
        print(f"\n[INFO] Test completed. Final JEV+ score: {jev_score:.6f}")
    else:
        print("[WARNING] No journey data available for testing") 