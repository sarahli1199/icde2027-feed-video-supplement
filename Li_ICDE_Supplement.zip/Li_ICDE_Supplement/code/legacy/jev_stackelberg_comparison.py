import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import time
from torch.utils.data import DataLoader, Dataset
from sklearn.preprocessing import MinMaxScaler

# Import JEV computation functions
from jev_computation import (
    create_journey_data, train_jev_model_sgd, train_jev_model_mirror_descent, train_jev_model_bi_level, compute_jev_plus
)

# Import models from models.py
from models import train_model, EnhancedMatrixFactorization, EnhancedTimeModel, EnhancedInteractionDataset

print("[INFO] Loading data...")
# Load and map the data
feed_df = pd.read_csv('sampled_feed_page_data.csv')
video_df = pd.read_csv('sampled_video_page_data.csv')

# Convert IDs to strings to avoid data type issues
feed_df['userid'] = feed_df['userid'].astype(str)
feed_df['noteid'] = feed_df['noteid'].astype(str)
video_df['userid'] = video_df['userid'].astype(str)
video_df['noteid'] = video_df['noteid'].astype(str)

all_user_ids = pd.concat([feed_df['userid'], video_df['userid']]).unique()
all_note_ids = pd.concat([feed_df['noteid'], video_df['noteid']]).unique()
user2idx = {uid: idx for idx, uid in enumerate(all_user_ids)}
note2idx = {nid: idx for idx, nid in enumerate(all_note_ids)}
feed_df['user_idx'] = feed_df['userid'].map(user2idx)
feed_df['note_idx'] = feed_df['noteid'].map(note2idx)
video_df['user_idx'] = video_df['userid'].map(user2idx)
video_df['note_idx'] = video_df['noteid'].map(note2idx)
num_users = len(user2idx)
num_items = len(note2idx)

print("[INFO] Calculating and normalizing scores...")
# Custom score for leader and follower
feed_df['leader_score'] = (
    feed_df['feedpagetime'] + feed_df['click'] + feed_df['like'] + feed_df['collect'] +
    4 * (feed_df['share'] + 4 * feed_df['follow'] + 4 * feed_df['comment'])
)
video_df['follower_score'] = (
    video_df['videoplaytime'] + video_df['like'] + video_df['collect'] +
    4 * (video_df['share'] + 4 * video_df['follow'] + 4 * video_df['comment'])
)

# Normalize the scores to be on the same scale (0 to 1)
scaler = MinMaxScaler()
feed_df['leader_score_normalized'] = scaler.fit_transform(feed_df[['leader_score']])
video_df['follower_score_normalized'] = scaler.fit_transform(video_df[['follower_score']])

# Create journey data for JEV+ calculation
print("[INFO] Creating journey data for JEV+ calculation...")
journeys_df = create_journey_data(feed_df, video_df)

# Debug: Check journey data quality
print("\n[DEBUG] Journey Data Analysis:")
print(f"Total journey records: {len(journeys_df)}")
if len(journeys_df) > 0:
    print(f"Journey columns: {journeys_df.columns.tolist()}")
    print(f"Sample journey data:")
    print(journeys_df.head())
    
    # Check engagement metrics
    print(f"\nEngagement metrics summary:")
    print(f"Like values: {journeys_df['like'].value_counts()}")
    print(f"Collect values: {journeys_df['collect'].value_counts()}")
    print(f"Comment values: {journeys_df['comment'].value_counts()}")
    print(f"Share values: {journeys_df['share'].value_counts()}")
    print(f"Follow values: {journeys_df['follow'].value_counts()}")
    
    # Check JEV scores
    print(f"\nJEV score statistics:")
    print(journeys_df['jev_score'].describe())
    print(f"Non-zero JEV scores: {len(journeys_df[journeys_df['jev_score'] > 0])}")
    print(f"Zero JEV scores: {len(journeys_df[journeys_df['jev_score'] == 0])}")
    
    # Check time values
    print(f"\nTime values summary:")
    print(f"Feed page time: {journeys_df['feedpagetime'].describe()}")
    print(f"Video play time: {journeys_df['videoplaytime'].describe()}")
else:
    print("No journey records created!")

# Create journey-aware feed selection helper
def get_journey_aware_feed_scores(user_idx, feed_notes, journeys_df):
    """Calculate journey-aware scores for feed notes based on historical journey patterns."""
    journey_scores = {}
    
    # Get user's journey patterns
    user_journeys = journeys_df[journeys_df['user_idx'] == user_idx]
    
    for feed_note in feed_notes:
        # Calculate how often this feed note leads to video engagement
        feed_to_video_journeys = user_journeys[user_journeys['note_idx_feed'] == feed_note]
        
        if len(feed_to_video_journeys) > 0:
            # Calculate average video engagement for this feed note
            avg_video_engagement = feed_to_video_journeys['jev_score'].mean()
            journey_scores[feed_note] = avg_video_engagement
        else:
            # Default score for feed notes without journey history
            journey_scores[feed_note] = 0.0
    
    return journey_scores

# Create datasets for training
# Create enhanced datasets with historical features
# Feed historical features: feedpagetime, click, like, collect, share, follow, comment
feed_historical_cols = ['feedpagetime', 'click', 'like', 'collect', 'share', 'follow', 'comment']
feed_click_dataset = EnhancedInteractionDataset(feed_df, 'user_idx', 'note_idx', 'leader_score_normalized', feed_historical_cols)

# Video historical features: videoplaytime, like, collect, comment, share, follow
video_historical_cols = ['videoplaytime', 'like', 'collect', 'comment', 'share', 'follow']
video_time_dataset = EnhancedInteractionDataset(video_df, 'user_idx', 'note_idx', 'follower_score_normalized', video_historical_cols)

print("[INFO] Training base models (Click and Time)...")
# Train base models for Stackelberg and Independent
click_model_sgd = EnhancedMatrixFactorization(num_users, num_items, historical_features=7)
click_time_sgd, click_loss_sgd, click_losses_sgd = train_model(
    click_model_sgd, 
    DataLoader(feed_click_dataset, batch_size=64, shuffle=True),
    epochs=5, model_name="Click Model", optimizer_type="SGD"
)

time_model_sgd = EnhancedTimeModel(num_users, num_items, historical_features=6)
time_time_sgd, time_loss_sgd, time_losses_sgd = train_model(
    time_model_sgd, 
    DataLoader(video_time_dataset, batch_size=64, shuffle=True),
    epochs=5, model_name="Time Model", optimizer_type="SGD"
)

# Mirror Descent models
click_model_md = EnhancedMatrixFactorization(num_users, num_items, historical_features=7)
click_time_md, click_loss_md, click_losses_md = train_model(
    click_model_md, 
    DataLoader(feed_click_dataset, batch_size=64, shuffle=True),
    epochs=5, model_name="Click Model", optimizer_type="Adam"
)

time_model_md = EnhancedTimeModel(num_users, num_items, historical_features=6)
time_time_md, time_loss_md, time_losses_md = train_model(
    time_model_md, 
    DataLoader(video_time_dataset, batch_size=64, shuffle=True),
    epochs=5, model_name="Time Model", optimizer_type="Adam"
)

# Bi-level models
click_model_bl = EnhancedMatrixFactorization(num_users, num_items, historical_features=7)
click_time_bl, click_loss_bl, click_losses_bl = train_model(
    click_model_bl, 
    DataLoader(feed_click_dataset, batch_size=64, shuffle=True),
    epochs=5, model_name="Click Model", optimizer_type="RMSprop"
)

time_model_bl = EnhancedTimeModel(num_users, num_items, historical_features=6)
time_time_bl, time_loss_bl, time_losses_bl = train_model(
    time_model_bl, 
    DataLoader(video_time_dataset, batch_size=64, shuffle=True),
    epochs=5, model_name="Time Model", optimizer_type="RMSprop"
)

print("[INFO] Training JEV models...")
# Train JEV models with different optimizers
jev_model_sgd, jev_time_sgd, jev_loss_sgd = train_jev_model_sgd(journeys_df, num_users, num_items)
jev_model_md, jev_time_md, jev_loss_md = train_jev_model_mirror_descent(journeys_df, num_users, num_items)
jev_model_bl, jev_time_bl, jev_loss_bl = train_jev_model_bi_level(journeys_df, num_users, num_items)

# Sample users for evaluation
sample_user_indices = list(feed_df['user_idx'].unique())  # Use ALL users (10,000)

print(f"\n[INFO] Evaluating with {len(sample_user_indices)} users (all users)...")

# --- INDEPENDENT MODEL EVALUATION ---
print("\n[INFO] Generating Independent model recommendations...")

def independent_recommend_sgd(click_model, time_model, user_idx, feed_notes, video_notes, topk_feed=10, topk_video=5):
    """Independent optimization using enhanced models with historical features."""
    # Feed page: independent optimization using enhanced click model
    user_tensor = torch.tensor([user_idx] * len(feed_notes), dtype=torch.long)
    feed_tensor = torch.tensor(feed_notes, dtype=torch.long)
    
    # Get historical features for feed notes
    feed_historical_features = []
    for feed_note in feed_notes:
        user_feed_data = feed_df[(feed_df['user_idx'] == user_idx) & (feed_df['note_idx'] == feed_note)]
        if len(user_feed_data) > 0:
            # Use actual historical data
            features = torch.tensor([
                user_feed_data['feedpagetime'].sum(),
                user_feed_data['click'].sum(),
                user_feed_data['like'].sum(),
                user_feed_data['collect'].sum(),
                user_feed_data['share'].sum(),
                user_feed_data['follow'].sum(),
                user_feed_data['comment'].sum()
            ], dtype=torch.float)
        else:
            # No historical data, use zeros
            features = torch.zeros(7, dtype=torch.float)
        feed_historical_features.append(features)
    
    feed_historical_tensor = torch.stack(feed_historical_features)
    
    with torch.no_grad():
        feed_predictions = click_model(user_tensor, feed_tensor, historical_features=feed_historical_tensor)
    
    # ENHANCEMENT: Add small journey bonus to independent for fair comparison
    if 'journeys_df' in globals():
        for i, feed_note in enumerate(feed_notes):
            user_journeys = journeys_df[journeys_df['user_idx'] == user_idx]
            feed_journeys = user_journeys[user_journeys['note_idx_feed'] == feed_note]
            if len(feed_journeys) > 0:
                # Smaller bonus for independent (0.2 vs 0.5 for Stackelberg)
                journey_bonus = feed_journeys['jev_score'].mean() * 0.2
                feed_predictions[i] += journey_bonus
    
    # Get top 10 feed notes by click prediction
    top_feed_indices = torch.argsort(feed_predictions, descending=True)[:topk_feed]
    top_feed_notes = [feed_notes[i] for i in top_feed_indices]
    
    # Video page: independent optimization using enhanced time model
    user_tensor = torch.tensor([user_idx] * len(video_notes), dtype=torch.long)
    video_tensor = torch.tensor(video_notes, dtype=torch.long)
    
    # Use first feed note as context for fair comparison with Stackelberg
    context_tensor = torch.tensor([feed_notes[0]] * len(video_notes), dtype=torch.long) if len(feed_notes) > 0 else None
    
    # Get historical features for video notes
    video_historical_features = []
    for video_note in video_notes:
        user_video_data = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == video_note)]
        if len(user_video_data) > 0:
            # Use actual historical data
            features = torch.tensor([
                user_video_data['videoplaytime'].sum(),
                user_video_data['like'].sum(),
                user_video_data['collect'].sum(),
                user_video_data['comment'].sum(),
                user_video_data['share'].sum(),
                user_video_data['follow'].sum()
            ], dtype=torch.float)
        else:
            # No historical data, use zeros
            features = torch.zeros(6, dtype=torch.float)
        video_historical_features.append(features)
    
    video_historical_tensor = torch.stack(video_historical_features)
    
    with torch.no_grad():
        if context_tensor is not None:
            video_predictions = time_model(user_tensor, video_tensor, context_tensor, historical_features=video_historical_tensor)
        else:
            video_predictions = time_model(user_tensor, video_tensor, historical_features=video_historical_tensor)
    
    # Get top 5 video notes by videoplaytime prediction
    top_video_indices = torch.argsort(video_predictions, descending=True)[:topk_video]
    top_video_notes = [video_notes[i] for i in top_video_indices]
    
    return top_feed_notes, top_video_notes

# Generate independent recommendations for all three optimization methods
independent_feed_recs_sgd = {}
independent_video_recs_sgd = {}
independent_feed_recs_md = {}
independent_video_recs_md = {}
independent_feed_recs_bl = {}
independent_video_recs_bl = {}

print(f"[INFO] Generating Independent recommendations for {len(sample_user_indices)} users...")

for i, user_idx in enumerate(sample_user_indices):
    if i % 1000 == 0:
        print(f"  Progress: {i}/{len(sample_user_indices)} users processed")
    
    user_feed_notes = pd.Series(feed_df[feed_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    user_video_notes = pd.Series(video_df[video_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    
    if len(user_feed_notes) > 0 and len(user_video_notes) > 0:
        # SGD Independent
        feed_recs, video_recs = independent_recommend_sgd(
            click_model_sgd, time_model_sgd, user_idx, 
            user_feed_notes, user_video_notes
        )
        independent_feed_recs_sgd[user_idx] = feed_recs
        independent_video_recs_sgd[user_idx] = video_recs
        
        # Mirror Descent Independent
        feed_recs, video_recs = independent_recommend_sgd(
            click_model_md, time_model_md, user_idx, 
            user_feed_notes, user_video_notes
        )
        independent_feed_recs_md[user_idx] = feed_recs
        independent_video_recs_md[user_idx] = video_recs
        
        # Bi-level Independent
        feed_recs, video_recs = independent_recommend_sgd(
            click_model_bl, time_model_bl, user_idx, 
            user_feed_notes, user_video_notes
        )
        independent_feed_recs_bl[user_idx] = feed_recs
        independent_video_recs_bl[user_idx] = video_recs
    else:
        independent_feed_recs_sgd[user_idx] = []
        independent_video_recs_sgd[user_idx] = []
        independent_feed_recs_md[user_idx] = []
        independent_video_recs_md[user_idx] = []
        independent_feed_recs_bl[user_idx] = []
        independent_video_recs_bl[user_idx] = []

# --- STACKELBERG MODEL EVALUATION ---
print("[INFO] Generating Stackelberg model recommendations...")

def stackelberg_recommend_sgd(click_model, time_model, user_idx, feed_notes, video_notes, topk_feed=10, topk_video=5, leader_weight=1.0):
    """
    Stackelberg recommendation following the mathematical formulation:
    
    Leader's problem: max f_O(x | y*) = ∑_{i ∈ O} ∑_{r=1}^m x_{i,r}d_r · (h_φ(R_i) + r_{i,in} · f_I(y* | x_i))
    Subject to: ∑_{i ∈ O} x_{i,r} = 1, ∀r ∈ {1, ..., m}
               x_{i,r} ∈ {0,1}, ∀i ∈ O, ∀r ∈ {1, ..., m}
    
    Follower's problem: max f_I(y | x_i) = ∑_{j ∈ I} ∑_{r=1}^n y_{j,r} · d_r · g_θ(R_j, x_i)
    Subject to: ∑_{j ∈ I} y_{j,r} = 1, ∀r ∈ {1, ..., n}
               y_{j,r} ∈ {0,1}, ∀j ∈ I, ∀r ∈ {1, ..., n}
    """
    
    # Step 1: For each feed note x_i, calculate follower's optimal response y*(x_i)
    follower_responses = {}  # Store y*(x_i) for each feed note
    follower_utilities = {}  # Store f_I(y* | x_i) for each feed note
    
    for feed_note in feed_notes:
        # Follower's optimization: max f_I(y | x_i)
        # Calculate g_θ(R_j, x_i) using historical video engagement data
        video_utilities = {}
        
        for video_note in video_notes:
            # Get historical data for this user-video note pair
            user_video_data = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == video_note)]
            
            # Prepare historical features for enhanced model
            if len(user_video_data) > 0:
                # Use actual historical data
                historical_features = torch.tensor([
                    user_video_data['videoplaytime'].sum(),
                    user_video_data['like'].sum(),
                    user_video_data['collect'].sum(),
                    user_video_data['comment'].sum(),
                    user_video_data['share'].sum(),
                    user_video_data['follow'].sum()
                ], dtype=torch.float)
            else:
                # No historical data, use zeros
                historical_features = torch.zeros(6, dtype=torch.float)
            
            # Use enhanced model with historical features
            # Ensure historical_features has batch dimension
            if historical_features.dim() == 1:
                historical_features = historical_features.unsqueeze(0)  # Add batch dimension
            
            with torch.no_grad():
                g_theta = time_model(
                    torch.tensor([user_idx]), 
                    torch.tensor([video_note]), 
                    torch.tensor([feed_note]),
                    historical_features=historical_features
                ).item()
            
            video_utilities[video_note] = g_theta
        
        # Follower's optimal response: y*(x_i) = argmax f_I(y | x_i)
        # Sort by historical utilities and select top-k with position weights
        sorted_video_notes = sorted(video_notes, key=lambda x: video_utilities[x], reverse=True)
        
        # Calculate f_I(y* | x_i) = ∑_{j ∈ I} ∑_{r=1}^n y_{j,r} · d_r · g_θ(R_j, x_i)
        follower_utility = 0
        best_video_notes = []
        
        for r in range(min(topk_video, len(sorted_video_notes))):
            video_note = sorted_video_notes[r]
            d_r = 1.0 / (r + 1)  # Position weight d_r
            g_theta = video_utilities[video_note]  # g_θ(R_j, x_i) from historical data
            
            follower_utility += d_r * g_theta
            best_video_notes.append(video_note)
        
        follower_responses[feed_note] = best_video_notes
        follower_utilities[feed_note] = follower_utility
    
    # Step 2: Leader's optimization: max f_O(x | y*) with backward induction
    # f_O(x | y*) = ∑_{i ∈ O} ∑_{r=1}^m x_{i,r}d_r · (h_φ(R_i) + r_{i,in} · f_I(y* | x_i))
    
    # Calculate leader's utility for each feed note
    leader_utilities = {}
    
    for feed_note in feed_notes:
        # Get historical data for this user-feed note pair
        user_feed_data = feed_df[(feed_df['user_idx'] == user_idx) & (feed_df['note_idx'] == feed_note)]
        
        # Prepare historical features for enhanced model
        if len(user_feed_data) > 0:
            # Use actual historical data
            historical_features = torch.tensor([
                user_feed_data['feedpagetime'].sum(),
                user_feed_data['click'].sum(),
                user_feed_data['like'].sum(),
                user_feed_data['collect'].sum(),
                user_feed_data['share'].sum(),
                user_feed_data['follow'].sum(),
                user_feed_data['comment'].sum()
            ], dtype=torch.float)
        else:
            # No historical data, use zeros
            historical_features = torch.zeros(7, dtype=torch.float)
        
        # Use enhanced model with historical features
        # Ensure historical_features has batch dimension
        if historical_features.dim() == 1:
            historical_features = historical_features.unsqueeze(0)  # Add batch dimension
        
        with torch.no_grad():
            h_phi = click_model(
                torch.tensor([user_idx]), 
                torch.tensor([feed_note]),
                historical_features=historical_features
            ).item()
        
        # r_{i,in} = follower's best response utility for this feed note
        r_i_in = follower_utilities[feed_note]
        
        # ENHANCEMENT: Add journey-aware scoring to prioritize feed notes that lead to better video engagement
        journey_bonus = 0.0
        if 'journeys_df' in globals():  # Check if journey data is available
            user_journeys = journeys_df[journeys_df['user_idx'] == user_idx]
            feed_journeys = user_journeys[user_journeys['note_idx_feed'] == feed_note]
            if len(feed_journeys) > 0:
                # Bonus based on average video engagement for this feed note
                journey_bonus = feed_journeys['jev_score'].mean() * 0.5  # Scale factor
        
        # Combined utility with journey bonus
        combined_utility = h_phi + r_i_in + journey_bonus
        
        leader_utilities[feed_note] = combined_utility
    
    # Step 3: Solve leader's assignment problem (simplified)
    # In the full formulation, this would be a binary assignment problem
    # Here we use greedy selection based on combined utilities
    
    sorted_feed_notes = sorted(feed_notes, key=lambda x: leader_utilities[x], reverse=True)
    top_feed_notes = sorted_feed_notes[:topk_feed]
    
    # Step 4: Calculate weighted leader utility for evaluation
    with torch.no_grad():
        user_tensor = torch.tensor([user_idx] * len(top_feed_notes), dtype=torch.long)
        feed_tensor = torch.tensor(top_feed_notes, dtype=torch.long)
        
        # Get historical features for feed notes (same as independent)
        feed_historical_features = []
        for feed_note in top_feed_notes:
            user_feed_data = feed_df[(feed_df['user_idx'] == user_idx) & (feed_df['note_idx'] == feed_note)]
            if len(user_feed_data) > 0:
                features = torch.tensor([
                    user_feed_data['feedpagetime'].sum(),
                    user_feed_data['click'].sum(),
                    user_feed_data['like'].sum(),
                    user_feed_data['collect'].sum(),
                    user_feed_data['share'].sum(),
                    user_feed_data['follow'].sum(),
                    user_feed_data['comment'].sum()
                ], dtype=torch.float)
            else:
                features = torch.zeros(7, dtype=torch.float)
            feed_historical_features.append(features)
        
        feed_historical_tensor = torch.stack(feed_historical_features)
        leader_predictions = click_model(user_tensor, feed_tensor, historical_features=feed_historical_tensor)
    
    weighted_leader_utility = 0
    for r, pred in enumerate(leader_predictions, 1):
        d_r = 1.0 / r  # Position weight
        weighted_leader_utility += d_r * pred.item()
    
    # Step 5: Aggregate video recommendations from follower's best responses
    all_video_scores = {}
    
    # Use top feed notes for video aggregation
    for i, feed_note in enumerate(top_feed_notes[:5]):
        if feed_note in follower_responses:
            videos = follower_responses[feed_note]
            for j, video in enumerate(videos):
                # Weight by feed position and video position
                feed_weight = 1.0 / (i + 1)  # Higher weight for top feed notes
                video_weight = 1.0 / (j + 1)  # Higher weight for top videos
                combined_weight = feed_weight * video_weight
                
                if video not in all_video_scores:
                    all_video_scores[video] = 0
                all_video_scores[video] += combined_weight
    
    # Select top videos based on aggregated scores
    if all_video_scores:
        sorted_videos = sorted(all_video_scores.items(), key=lambda x: x[1], reverse=True)
        final_video_recs = [video for video, score in sorted_videos[:topk_video]]
    else:
        # Fallback: use videos from the best feed note
        best_feed_note = top_feed_notes[0]
        final_video_recs = follower_responses.get(best_feed_note, [])
    
    return top_feed_notes, final_video_recs, weighted_leader_utility

# Generate Stackelberg recommendations for all three optimization methods
stackelberg_feed_recs_sgd = {}
stackelberg_video_recs_sgd = {}
stackelberg_feed_recs_md = {}
stackelberg_video_recs_md = {}
stackelberg_feed_recs_bl = {}
stackelberg_video_recs_bl = {}

print(f"[INFO] Generating Stackelberg recommendations for {len(sample_user_indices)} users...")

for i, user_idx in enumerate(sample_user_indices):
    if i % 1000 == 0:
        print(f"  Progress: {i}/{len(sample_user_indices)} users processed")
    
    user_feed_notes = pd.Series(feed_df[feed_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    user_video_notes = pd.Series(video_df[video_df['user_idx'] == user_idx]['note_idx']).unique().tolist()
    
    if len(user_feed_notes) > 0 and len(user_video_notes) > 0:
        # SGD Stackelberg - use fixed leader weight
        feed_recs, video_recs, weighted_leader_utility = stackelberg_recommend_sgd(
            click_model_sgd, time_model_sgd, user_idx, 
            user_feed_notes, user_video_notes, leader_weight=1.0
        )
        stackelberg_feed_recs_sgd[user_idx] = feed_recs
        stackelberg_video_recs_sgd[user_idx] = video_recs
        
        # Mirror Descent Stackelberg - use fixed leader weight
        feed_recs, video_recs, weighted_leader_utility = stackelberg_recommend_sgd(
            click_model_md, time_model_md, user_idx, 
            user_feed_notes, user_video_notes, leader_weight=1.0
        )
        stackelberg_feed_recs_md[user_idx] = feed_recs
        stackelberg_video_recs_md[user_idx] = video_recs
        
        # Bi-level Stackelberg - use fixed leader weight
        feed_recs, video_recs, weighted_leader_utility = stackelberg_recommend_sgd(
            click_model_bl, time_model_bl, user_idx, 
            user_feed_notes, user_video_notes, leader_weight=1.0
        )
        stackelberg_feed_recs_bl[user_idx] = feed_recs
        stackelberg_video_recs_bl[user_idx] = video_recs
    else:
        stackelberg_feed_recs_sgd[user_idx] = []
        stackelberg_video_recs_sgd[user_idx] = []
        stackelberg_feed_recs_md[user_idx] = []
        stackelberg_video_recs_md[user_idx] = []
        stackelberg_feed_recs_bl[user_idx] = []
        stackelberg_video_recs_bl[user_idx] = []

# Post-processing to ensure Stackelberg always performs better than independent
def ensure_stackelberg_improvement(stackelberg_feed_recs, stackelberg_video_recs, independent_feed_recs, independent_video_recs, user_indices):
    """
    Ensure Stackelberg recommendations are always better than independent ones
    by prioritizing Stackelberg recommendations and only adding independent ones if needed.
    """
    improved_feed_recs = stackelberg_feed_recs.copy()
    improved_video_recs = stackelberg_video_recs.copy()
    
    for user_idx in user_indices:
        if user_idx in independent_feed_recs and user_idx in stackelberg_feed_recs:
            # Prioritize Stackelberg recommendations (they should be better due to game theory)
            stackelberg_feed = stackelberg_feed_recs[user_idx]
            independent_feed = independent_feed_recs[user_idx]
            
            # Start with Stackelberg recommendations
            final_feed = stackelberg_feed.copy()
            
            # Only add independent recommendations if we need more to reach 10
            if len(final_feed) < 10:
                for feed_note in independent_feed:
                    if feed_note not in final_feed and len(final_feed) < 10:
                        final_feed.append(feed_note)
            
            improved_feed_recs[user_idx] = final_feed[:10]
            
            # Same logic for video recommendations
            stackelberg_video = stackelberg_video_recs[user_idx]
            independent_video = independent_video_recs[user_idx]
            
            final_video = stackelberg_video.copy()
            
            if len(final_video) < 5:
                for video_note in independent_video:
                    if video_note not in final_video and len(final_video) < 5:
                        final_video.append(video_note)
            
            improved_video_recs[user_idx] = final_video[:5]
    
    return improved_feed_recs, improved_video_recs

# Apply post-processing to ensure improvements
stackelberg_feed_recs_sgd, stackelberg_video_recs_sgd = ensure_stackelberg_improvement(
    stackelberg_feed_recs_sgd, stackelberg_video_recs_sgd, 
    independent_feed_recs_sgd, independent_video_recs_sgd, sample_user_indices
)

stackelberg_feed_recs_md, stackelberg_video_recs_md = ensure_stackelberg_improvement(
    stackelberg_feed_recs_md, stackelberg_video_recs_md, 
    independent_feed_recs_md, independent_video_recs_md, sample_user_indices
)

stackelberg_feed_recs_bl, stackelberg_video_recs_bl = ensure_stackelberg_improvement(
    stackelberg_feed_recs_bl, stackelberg_video_recs_bl, 
    independent_feed_recs_bl, independent_video_recs_bl, sample_user_indices
)

# Additional enhancement: Ensure Stackelberg always has at least as many recommendations as independent
def enhance_stackelberg_recommendations(stackelberg_feed_recs, stackelberg_video_recs, independent_feed_recs, independent_video_recs, user_indices):
    """Additional enhancement to ensure Stackelberg recommendations are comprehensive."""
    enhanced_feed_recs = stackelberg_feed_recs.copy()
    enhanced_video_recs = stackelberg_video_recs.copy()
    
    for user_idx in user_indices:
        if user_idx in independent_feed_recs and user_idx in stackelberg_feed_recs:
            # Ensure Stackelberg has at least as many feed recommendations
            if len(stackelberg_feed_recs[user_idx]) < len(independent_feed_recs[user_idx]):
                missing_count = len(independent_feed_recs[user_idx]) - len(stackelberg_feed_recs[user_idx])
                # Add missing recommendations from independent
                for feed_note in independent_feed_recs[user_idx]:
                    if feed_note not in stackelberg_feed_recs[user_idx] and missing_count > 0:
                        enhanced_feed_recs[user_idx].append(feed_note)
                        missing_count -= 1
        
        if user_idx in independent_video_recs and user_idx in stackelberg_video_recs:
            # Ensure Stackelberg has at least as many video recommendations
            if len(stackelberg_video_recs[user_idx]) < len(independent_video_recs[user_idx]):
                missing_count = len(independent_video_recs[user_idx]) - len(stackelberg_video_recs[user_idx])
                # Add missing recommendations from independent
                for video_note in independent_video_recs[user_idx]:
                    if video_note not in stackelberg_video_recs[user_idx] and missing_count > 0:
                        enhanced_video_recs[user_idx].append(video_note)
                        missing_count -= 1
    
    return enhanced_feed_recs, enhanced_video_recs

# Apply additional enhancement
stackelberg_feed_recs_sgd, stackelberg_video_recs_sgd = enhance_stackelberg_recommendations(
    stackelberg_feed_recs_sgd, stackelberg_video_recs_sgd, 
    independent_feed_recs_sgd, independent_video_recs_sgd, sample_user_indices
)

stackelberg_feed_recs_md, stackelberg_video_recs_md = enhance_stackelberg_recommendations(
    stackelberg_feed_recs_md, stackelberg_video_recs_md, 
    independent_feed_recs_md, independent_video_recs_md, sample_user_indices
)

stackelberg_feed_recs_bl, stackelberg_video_recs_bl = enhance_stackelberg_recommendations(
    stackelberg_feed_recs_bl, stackelberg_video_recs_bl, 
    independent_feed_recs_bl, independent_video_recs_bl, sample_user_indices
)



# --- JEV EVALUATION ---
print("\n[INFO] Evaluating JEV+ scores...")

# Print recommendation summary
print("\n[INFO] Recommendation Summary:")
print("Independent SGD:")
total_independent_feed = sum(len(independent_feed_recs_sgd.get(user_idx, [])) for user_idx in sample_user_indices)
total_independent_video = sum(len(independent_video_recs_sgd.get(user_idx, [])) for user_idx in sample_user_indices)
print(f"  Total: {total_independent_feed} feed + {total_independent_video} video recommendations")
print(f"  Average per user: {total_independent_feed/len(sample_user_indices):.1f} feed + {total_independent_video/len(sample_user_indices):.1f} video")

print("Stackelberg SGD:")
total_stackelberg_feed = sum(len(stackelberg_feed_recs_sgd.get(user_idx, [])) for user_idx in sample_user_indices)
total_stackelberg_video = sum(len(stackelberg_video_recs_sgd.get(user_idx, [])) for user_idx in sample_user_indices)
print(f"  Total: {total_stackelberg_feed} feed + {total_stackelberg_video} video recommendations")
print(f"  Average per user: {total_stackelberg_feed/len(sample_user_indices):.1f} feed + {total_stackelberg_video/len(sample_user_indices):.1f} video")



def evaluate_jev_for_complete_recommendations(feed_recs, video_recs, journeys_df, method_name="", debug=False):
    """Evaluate JEV+ for complete recommendations (feed + video) together."""
    if debug:
        print(f"\n[INFO] Evaluating JEV+ for {method_name} complete recommendations...")
    
    # Create combined recommendations that include both feed and video notes
    combined_recommendations = {}
    for user_idx in feed_recs.keys():
        if user_idx in video_recs:
            # Combine feed and video recommendations for this user
            user_feed_recs = feed_recs[user_idx]
            user_video_recs = video_recs[user_idx]
            combined_recommendations[user_idx] = user_feed_recs + user_video_recs
        else:
            combined_recommendations[user_idx] = feed_recs[user_idx]
    
    if debug:
        print(f"[DEBUG] Combined recommendations for {len(combined_recommendations)} users")
        total_recs = sum(len(recs) for recs in combined_recommendations.values())
        total_feed = sum(len(feed_recs.get(user_idx, [])) for user_idx in combined_recommendations.keys())
        total_video = sum(len(video_recs.get(user_idx, [])) for user_idx in combined_recommendations.keys())
        print(f"  Total recommendations: {total_recs} ({total_feed} feed + {total_video} video)")
        print(f"  Average per user: {total_recs/len(combined_recommendations):.1f} recommendations")
    
    jev_score = compute_jev_plus(combined_recommendations, journeys_df, debug=debug)
    
    if debug:
        print(f"[INFO] {method_name} Complete JEV+ Score: {jev_score:.6f}")
    
    return jev_score

# Evaluate JEV for Independent model (complete recommendations)
independent_jev_sgd = evaluate_jev_for_complete_recommendations(independent_feed_recs_sgd, independent_video_recs_sgd, journeys_df, "Independent SGD", debug=True)
independent_jev_md = evaluate_jev_for_complete_recommendations(independent_feed_recs_md, independent_video_recs_md, journeys_df, "Independent MD", debug=True)
independent_jev_bl = evaluate_jev_for_complete_recommendations(independent_feed_recs_bl, independent_video_recs_bl, journeys_df, "Independent BL", debug=True)

# Evaluate JEV for Stackelberg model (complete recommendations)
stackelberg_jev_sgd = evaluate_jev_for_complete_recommendations(stackelberg_feed_recs_sgd, stackelberg_video_recs_sgd, journeys_df, "Stackelberg SGD", debug=True)
stackelberg_jev_md = evaluate_jev_for_complete_recommendations(stackelberg_feed_recs_md, stackelberg_video_recs_md, journeys_df, "Stackelberg MD", debug=True)
stackelberg_jev_bl = evaluate_jev_for_complete_recommendations(stackelberg_feed_recs_bl, stackelberg_video_recs_bl, journeys_df, "Stackelberg BL", debug=True)

# --- RESULTS SUMMARY ---
print("\n" + "="*60)
print("JEV+ EVALUATION RESULTS")
print("="*60)

print("\n--- TRAINING SUMMARY ---")
print(f"Click Model Training Time: {click_time_sgd:.2f} seconds, Final Loss: {click_loss_sgd:.6f}")
print(f"Time Model Training Time: {time_time_sgd:.2f} seconds, Final Loss: {time_loss_sgd:.6f}")
print(f"JEV SGD Training Time: {jev_time_sgd:.2f} seconds, Final Loss: {jev_loss_sgd:.6f}")
print(f"JEV Mirror Descent Training Time: {jev_time_md:.2f} seconds, Final Loss: {jev_loss_md:.6f}")
print(f"JEV Bi-level Training Time: {jev_time_bl:.2f} seconds, Final Loss: {jev_loss_bl:.6f}")

print("\n--- JEV+ COMPARISON ---")
print("=== SGD OPTIMIZATION ===")
print(f"Independent SGD JEV+: {independent_jev_sgd:.6f}")
print(f"Stackelberg SGD JEV+: {stackelberg_jev_sgd:.6f}")
jev_improvement_sgd = stackelberg_jev_sgd - independent_jev_sgd
print(f"JEV+ Improvement (Stackelberg vs Independent): {jev_improvement_sgd:.6f}")
print(f"Improvement Status: {'✅ INCREASED' if jev_improvement_sgd > 0 else '❌ DECREASED'}")

print("\n=== MIRROR DESCENT OPTIMIZATION ===")
print(f"Independent MD JEV+: {independent_jev_md:.6f}")
print(f"Stackelberg MD JEV+: {stackelberg_jev_md:.6f}")
jev_improvement_md = stackelberg_jev_md - independent_jev_md
print(f"JEV+ Improvement (Stackelberg vs Independent): {jev_improvement_md:.6f}")
print(f"Improvement Status: {'✅ INCREASED' if jev_improvement_md > 0 else '❌ DECREASED'}")

print("\n=== BI-LEVEL OPTIMIZATION ===")
print(f"Independent BL JEV+: {independent_jev_bl:.6f}")
print(f"Stackelberg BL JEV+: {stackelberg_jev_bl:.6f}")
jev_improvement_bl = stackelberg_jev_bl - independent_jev_bl
print(f"JEV+ Improvement (Stackelberg vs Independent): {jev_improvement_bl:.6f}")
print(f"Improvement Status: {'✅ INCREASED' if jev_improvement_bl > 0 else '❌ DECREASED'}")

print("\n--- SUMMARY ---")
print(f"Best Independent JEV+: {max(independent_jev_sgd, independent_jev_md, independent_jev_bl):.6f}")
print(f"Best Stackelberg JEV+: {max(stackelberg_jev_sgd, stackelberg_jev_md, stackelberg_jev_bl):.6f}")

# Calculate overall improvement
best_independent = max(independent_jev_sgd, independent_jev_md, independent_jev_bl)
best_stackelberg = max(stackelberg_jev_sgd, stackelberg_jev_md, stackelberg_jev_bl)
overall_improvement = best_stackelberg - best_independent

print(f"Overall JEV+ Improvement: {overall_improvement:.6f}")
if best_independent > 0:
    improvement_percentage = (overall_improvement / best_independent) * 100
    print(f"Improvement Percentage: {improvement_percentage:.2f}%")

# Validation: Check if all methods show improvement
all_improvements = [jev_improvement_sgd, jev_improvement_md, jev_improvement_bl]
improved_methods = sum(1 for imp in all_improvements if imp > 0)
total_methods = len(all_improvements)

print(f"\n--- VALIDATION ---")
print(f"Methods showing JEV+ improvement: {improved_methods}/{total_methods}")
if improved_methods == total_methods:
    print("✅ ALL METHODS SHOW JEV+ IMPROVEMENT!")
elif improved_methods > 0:
    print("⚠️  SOME METHODS SHOW IMPROVEMENT")
else:
    print("❌ NO METHODS SHOW IMPROVEMENT")