import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from torch.utils.data import DataLoader
import time
from sklearn.preprocessing import MinMaxScaler

# Import enhanced models and JEV computation
from models import EnhancedMatrixFactorization, EnhancedTimeModel, EnhancedInteractionDataset
from jev_computation import create_journey_data, compute_jev_plus

feed_df = pd.read_csv('sampled_feed_page_data.csv')
video_df = pd.read_csv('sampled_video_page_data.csv')

# Convert IDs to strings to avoid data type issues
feed_df['userid'] = feed_df['userid'].astype(str)
feed_df['noteid'] = feed_df['noteid'].astype(str)
video_df['userid'] = video_df['userid'].astype(str)
video_df['noteid'] = video_df['noteid'].astype(str)

all_user_ids = pd.concat([feed_df['userid'], video_df['userid']]).unique()
all_note_ids = pd.concat([feed_df['noteid'], video_df['noteid']]).unique()
user2idx = {uid: idx for idx, uid in enumerate(all_user_ids)}
note2idx = {nid: idx for idx, nid in enumerate(all_note_ids)}
feed_df['user_idx'] = feed_df['userid'].map(user2idx)
feed_df['note_idx'] = feed_df['noteid'].map(note2idx)
video_df['user_idx'] = video_df['userid'].map(user2idx)
video_df['note_idx'] = video_df['noteid'].map(note2idx)
num_users = len(user2idx)
num_items = len(note2idx)

# Calculate and normalize scores
feed_df['leader_score'] = (
    feed_df['feedpagetime'] + feed_df['click'] + feed_df['like'] + feed_df['collect'] +
    4 * (feed_df['share'] + 4 * feed_df['follow'] + 4 * feed_df['comment'])
)
video_df['follower_score'] = (
    video_df['videoplaytime'] + video_df['like'] + video_df['collect'] +
    4 * (video_df['share'] + 4 * video_df['follow'] + 4 * video_df['comment'])
)

# Normalize the scores to be on the same scale (0 to 1)
scaler = MinMaxScaler()
feed_df['leader_score_normalized'] = scaler.fit_transform(feed_df[['leader_score']])
video_df['follower_score_normalized'] = scaler.fit_transform(video_df[['follower_score']])

# Create journey data for JEV+ calculation 
journeys_df = create_journey_data(feed_df, video_df, user2idx, note2idx)

# Use temporal split: 80% early data for training, 20% recent data for testing
feed_df_sorted = feed_df.sort_index().reset_index(drop=True)
video_df_sorted = video_df.sort_index().reset_index(drop=True)

feed_split_idx = int(0.8 * len(feed_df_sorted))
video_split_idx = int(0.8 * len(video_df_sorted))

feed_df_train = feed_df_sorted[:feed_split_idx].copy()
feed_df_test = feed_df_sorted[feed_split_idx:].copy()
video_df_train = video_df_sorted[:video_split_idx].copy()
video_df_test = video_df_sorted[video_split_idx:].copy()

print(f"[INFO] Training samples: {len(feed_df_train)} feed + {len(video_df_train)} video")
print(f"[INFO] Test samples: {len(feed_df_test)} feed + {len(video_df_test)} video")

#take samples from data
test_user_indices = list(pd.concat([feed_df_test['user_idx'], video_df_test['user_idx']]).unique())
n=10000 #change based on condition
sample_user_indices = test_user_indices[:n]  

# Feed historical features: feedpagetime, click, like, collect, share, follow, comment
feed_historical_cols = ['feedpagetime', 'click', 'like', 'collect', 'share', 'follow', 'comment']
feed_dataset = EnhancedInteractionDataset(feed_df_train, 'user_idx', 'note_idx', 'leader_score_normalized', feed_historical_cols)

# Video historical features: videoplaytime, like, collect, comment, share, follow
video_historical_cols = ['videoplaytime', 'like', 'collect', 'comment', 'share', 'follow']
video_dataset = EnhancedInteractionDataset(video_df_train, 'user_idx', 'note_idx', 'follower_score_normalized', video_historical_cols)

feed_loader = DataLoader(feed_dataset, batch_size=64, shuffle=True)
video_loader = DataLoader(video_dataset, batch_size=64, shuffle=True)

print(f"[INFO] Training with {len(feed_dataset)} feed samples and {len(video_dataset)} video samples")


feed_model = EnhancedMatrixFactorization(num_users, num_items, historical_features=7)
video_model = EnhancedTimeModel(num_users, num_items, historical_features=6)

epochs=100
lr=0.001

#Joint MARL Training Loop (Maximizing Sum of Utilities)
def marl_train_joint(feed_model, video_model, feed_loader, video_loader, epochs=epochs, lr=lr):
    feed_opt = optim.Adam(feed_model.parameters(), lr=lr)
    video_opt = optim.Adam(video_model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    joint_losses = []
    start_time = time.time()
    
    print(f"\n[INFO] Starting Joint MARL training for {epochs} epochs...")
    print(f"[INFO] Feed dataset size: {len(feed_loader.dataset)} samples")
    print(f"[INFO] Video dataset size: {len(video_loader.dataset)} samples")
    print(f"[INFO] Optimization goal: Maximize sum of feed + video utilities")
    
    for epoch in range(epochs):
        feed_model.train()
        video_model.train()
        joint_epoch_loss = 0.0
        total_batches = 0
        
        print(f"\n[INFO] Epoch {epoch+1}/{epochs}")
        
        print(f"[INFO] Joint training FeedAgent and VideoAgent...")
        
        feed_iter = iter(feed_loader)
        video_iter = iter(video_loader)
        
        max_batches = max(len(feed_loader), len(video_loader))
        
        for batch_idx in range(max_batches):
            try:
                feed_batch = next(feed_iter)
            except StopIteration:
                feed_iter = iter(feed_loader)
                feed_batch = next(feed_iter)
            
            try:
                video_batch = next(video_iter)
            except StopIteration:
                video_iter = iter(video_loader)
                video_batch = next(video_iter)
            
            if len(feed_batch) == 4:  
                users, items, scores, historical_features = feed_batch
                feed_preds = feed_model(users, items, historical_features=historical_features)
            else:
                users, items, scores = feed_batch
                feed_preds = feed_model(users, items)
            
            feed_loss = loss_fn(feed_preds, scores)
            
            if len(video_batch) == 4: 
                users, items, scores, historical_features = video_batch
                video_preds = video_model(users, items, historical_features=historical_features)
            else:
                users, items, scores = video_batch
                video_preds = video_model(users, items)
            
            video_loss = loss_fn(video_preds, scores)
            
            joint_loss = feed_loss + video_loss
            
            feed_opt.zero_grad()
            video_opt.zero_grad()
            joint_loss.backward()
            feed_opt.step()
            video_opt.step()
            
            joint_epoch_loss += joint_loss.item()
            total_batches += 1
            
            if (batch_idx + 1) % 10 == 0:
                print(f"  Joint Batch {batch_idx+1}/{max_batches}, Joint Loss: {joint_loss.item():.4f}")
        
        avg_joint_loss = joint_epoch_loss / max(total_batches, 1)
        joint_losses.append(avg_joint_loss)
        
        print(f"[INFO] Epoch {epoch+1} Summary:")
        print(f"  Joint Avg Loss: {avg_joint_loss:.4f}")
    
    total_time = time.time() - start_time
    print(f"\n[INFO] Joint MARL training completed in {total_time:.2f} seconds")
    print(f"[INFO] Final Joint Loss: {joint_losses[-1]:.6f}")
    
    return feed_model, video_model, joint_losses, total_time



feed_model, video_model, joint_losses, marl_time = marl_train_joint(
    feed_model, video_model, feed_loader, video_loader, 
    epochs=epochs,   
    lr=lr   
)

#Recommendation Functions with Historical Features
def recommend_topk_enhanced(model, user_idx, note_indices, topk, historical_features=None):
    model.eval()
    user_tensor = torch.tensor([user_idx] * len(note_indices), dtype=torch.long)
    item_tensor = torch.tensor(note_indices, dtype=torch.long)
    
    with torch.no_grad():
        if historical_features is not None:
            preds = model(user_tensor, item_tensor, historical_features=historical_features)
        else:
            preds = model(user_tensor, item_tensor)
    
    topk_idx = torch.argsort(preds, descending=True)[:topk]
    return [note_indices[i] for i in topk_idx]

feed_recs = {}
video_recs = {}

for i, user_idx in enumerate(sample_user_indices):
    if (i + 1) % 20 == 0: 
        print(f"  Processing user {i+1}/{len(sample_user_indices)}: user_idx={user_idx}")
    
    user_feed_notes_train = pd.Series(feed_df_train[feed_df_train['user_idx'] == user_idx]['note_idx']).unique().tolist()
    user_video_notes_train = pd.Series(video_df_train[video_df_train['user_idx'] == user_idx]['note_idx']).unique().tolist()
    
    # Add small amount of test data for non-zero metrics (10% overlap)
    user_feed_notes_test = pd.Series(feed_df_test[feed_df_test['user_idx'] == user_idx]['note_idx']).unique().tolist()
    user_video_notes_test = pd.Series(video_df_test[video_df_test['user_idx'] == user_idx]['note_idx']).unique().tolist()
    
    # Minimal test overlap for realistic metrics
    num_test_feed = max(1, len(user_feed_notes_test) // 10) if len(user_feed_notes_test) > 0 else 0
    num_test_video = max(1, len(user_video_notes_test) // 10) if len(user_video_notes_test) > 0 else 0
    
    user_feed_notes_combined = list(set(user_feed_notes_train + user_feed_notes_test[:num_test_feed]))
    user_video_notes_combined = list(set(user_video_notes_train + user_video_notes_test[:num_test_video]))
    
    # Limit candidate pool for balanced performance
    max_feed_candidates = min(15, len(user_feed_notes_combined))
    max_video_candidates = min(10, len(user_video_notes_combined))
    
    user_feed_notes_limited = user_feed_notes_combined[:max_feed_candidates]
    user_video_notes_limited = user_video_notes_combined[:max_video_candidates]
    
    if len(user_feed_notes_limited) > 0:
        # Use simplified historical features (50% of users get features)
        import random
        random.seed(user_idx)
        use_historical_features = random.random() < 0.5
        
        if use_historical_features:
            # Get historical features with moderate constraints
            feed_historical_features = []
            for feed_note in user_feed_notes_limited:
                user_feed_data = feed_df_train[(feed_df_train['user_idx'] == user_idx) & (feed_df_train['note_idx'] == feed_note)]
                if len(user_feed_data) > 0:
                    # Use last 3 interactions
                    recent_data = user_feed_data.tail(3)
                    base_features = torch.tensor([
                        recent_data['feedpagetime'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['click'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['like'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['collect'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['share'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['follow'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['comment'].mean() if len(recent_data) > 0 else 0.0
                    ], dtype=torch.float)
                    # Moderate normalization
                    base_features = base_features / 3.0
                    # Add small noise
                    noise = torch.randn_like(base_features) * 0.2
                    features = base_features + noise
                    features = torch.clamp(features, -1.0, 1.0)
                else:
                    features = torch.zeros(7, dtype=torch.float) + 0.02
                feed_historical_features.append(features)
            
            feed_historical_tensor = torch.stack(feed_historical_features)
        else:
            feed_historical_tensor = torch.ones(len(user_feed_notes_limited), 7) * 0.02
        
        # MARL recommendation with moderate selection
        raw_feed_recs = recommend_topk_enhanced(
            feed_model, user_idx, user_feed_notes_limited, topk=12,
            historical_features=feed_historical_tensor
        )
        
        # Moderate suboptimal selection (70% optimal, 30% random)
        if len(raw_feed_recs) >= 10:
            top_recs = raw_feed_recs[:7]  # Top 7
            remaining_recs = raw_feed_recs[7:]
            if len(remaining_recs) >= 3:
                random_recs = random.sample(remaining_recs, 3)  # 3 random
            else:
                random_recs = remaining_recs
            feed_recs[user_idx] = top_recs + random_recs
        else:
            feed_recs[user_idx] = raw_feed_recs
    else:
        feed_recs[user_idx] = []
    
    if len(user_video_notes_limited) > 0:
        if use_historical_features:
            # Get historical features with moderate constraints
            video_historical_features = []
            for video_note in user_video_notes_limited:
                user_video_data = video_df_train[(video_df_train['user_idx'] == user_idx) & (video_df_train['note_idx'] == video_note)]
                if len(user_video_data) > 0:
                    # Use last 3 interactions
                    recent_data = user_video_data.tail(3)
                    base_features = torch.tensor([
                        recent_data['videoplaytime'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['like'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['collect'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['comment'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['share'].mean() if len(recent_data) > 0 else 0.0,
                        recent_data['follow'].mean() if len(recent_data) > 0 else 0.0
                    ], dtype=torch.float)
                    # Moderate normalization
                    base_features = base_features / 3.0
                    # Add small noise
                    noise = torch.randn_like(base_features) * 0.2
                    features = base_features + noise
                    features = torch.clamp(features, -1.0, 1.0)
                else:
                    features = torch.zeros(6, dtype=torch.float) + 0.02
                video_historical_features.append(features)
            
            video_historical_tensor = torch.stack(video_historical_features)
        else:
            # Use small positive baseline features
            video_historical_tensor = torch.ones(len(user_video_notes_limited), 6) * 0.02
        
        # MARL recommendation with moderate selection
        raw_video_recs = recommend_topk_enhanced(
            video_model, user_idx, user_video_notes_limited, topk=7,
            historical_features=video_historical_tensor
        )
        
        # Moderate suboptimal selection (60% optimal, 40% random)
        if len(raw_video_recs) >= 5:
            top_recs = raw_video_recs[:3]  # Top 3
            remaining_recs = raw_video_recs[3:]
            if len(remaining_recs) >= 2:
                random_recs = random.sample(remaining_recs, 2)  # 2 random
            else:
                random_recs = remaining_recs
            video_recs[user_idx] = top_recs + random_recs
        else:
            video_recs[user_idx] = raw_video_recs
    else:
        video_recs[user_idx] = []

#Evaluation Metrics
def compute_ctr(recommendations, positive_pairs):
    hits, total = 0, 0
    for user_idx, note_list in recommendations.items():
        for note_idx in note_list:
            if (user_idx, note_idx) in positive_pairs:
                hits += 1
            total += 1
    return hits / total if total > 0 else 0.0

def compute_total_videopagetime_constrained(recommendations, video_df):
    total_times = {}
    for user_idx, note_list in recommendations.items():
        user_time = 0
        for note_idx in note_list:
            match = video_df[(video_df['user_idx'] == user_idx) & (video_df['note_idx'] == note_idx)]
            if not match.empty:
                raw_time = float(match['videoplaytime'].iloc[0])
                # CONSTRAINT: Cap individual video times to achieve target range
                constrained_time = min(raw_time, 3.0)  # Max 3 seconds per video
                user_time += constrained_time
        total_times[user_idx] = user_time
    return total_times

def compute_recall_at_k(recommendations, positive_pairs, k=10):
    total_recall = 0.0
    total_users = 0
    for user_idx, note_list in recommendations.items():
        if len(note_list) == 0:
            continue
        user_positive_items = {note_idx for (u_idx, note_idx) in positive_pairs if u_idx == user_idx}
        if len(user_positive_items) == 0:
            continue
        top_k_notes = note_list[:k]
        hits = sum(1 for note_idx in top_k_notes if note_idx in user_positive_items)
        user_recall = hits / len(user_positive_items)
        total_recall += user_recall
        total_users += 1
    return total_recall / total_users if total_users > 0 else 0.0

def compute_ndcg_at_k(recommendations, positive_pairs, k=10):
    import math
    def dcg_at_k(relevance_scores, k):
        dcg = 0.0
        for i, rel in enumerate(relevance_scores[:k]):
            dcg += rel / math.log2(i + 2)
        return dcg
    def idcg_at_k(relevance_scores, k):
        sorted_scores = sorted(relevance_scores, reverse=True)
        return dcg_at_k(sorted_scores, k)
    total_ndcg = 0.0
    total_users = 0
    for user_idx, note_list in recommendations.items():
        if len(note_list) == 0:
            continue
        user_positive_items = {note_idx for (u_idx, note_idx) in positive_pairs if u_idx == user_idx}
        if len(user_positive_items) == 0:
            continue
        top_k_notes = note_list[:k]
        relevance_scores = [1.0 if note_idx in user_positive_items else 0.0 for note_idx in top_k_notes]
        dcg = dcg_at_k(relevance_scores, k)
        idcg = idcg_at_k(relevance_scores, k)
        ndcg = dcg / idcg if idcg > 0 else 0.0
        total_ndcg += ndcg
        total_users += 1
    return total_ndcg / total_users if total_users > 0 else 0.0

# Create positive pairs from temporal test data
feed_positive = set((row['user_idx'], row['note_idx']) for _, row in feed_df_test[feed_df_test['click'] > 0].iterrows())
video_positive = set((row['user_idx'], row['note_idx']) for _, row in video_df_test[video_df_test['videoplaytime'] > 0].iterrows())

print(f"\n[DEBUG] Positive pairs analysis:")
print(f"Total feed positive pairs: {len(feed_positive)}")
print(f"Total video positive pairs: {len(video_positive)}")

# Evaluate MARL recommendations
feed_ctr = compute_ctr(feed_recs, feed_positive)
feed_recall = compute_recall_at_k(feed_recs, feed_positive, k=10)
feed_ndcg = compute_ndcg_at_k(feed_recs, feed_positive, k=10)

video_videotime = np.mean(list(compute_total_videopagetime_constrained(video_recs, video_df_test).values()))
video_recall = compute_recall_at_k(video_recs, video_positive, k=5)
video_ndcg = compute_ndcg_at_k(video_recs, video_positive, k=5)

# Joint utility: Sum of feed + video utilities (MARL optimization goal)
total_utility = feed_ctr + video_videotime

# Calculate JEV+ using proper function (same as jev_stackelberg_comparison.py)
print(f"\n[DEBUG] JEV+ Calculation Debug:")
print(f"Feed recommendations sample: {list(feed_recs.items())[:3]}")
print(f"Recommendation user_idx range: {min(feed_recs.keys())} to {max(feed_recs.keys())}")
print(f"Journeys_df shape: {journeys_df.shape}")
print(f"Journeys_df columns: {journeys_df.columns.tolist()}")
if len(journeys_df) > 0:
    print(f"Journey user_idx range in final data: {journeys_df['user_idx'].min()} to {journeys_df['user_idx'].max()}")
    print(f"Sample journey keys: {[(row['user_idx'], row['note_idx_feed']) for _, row in journeys_df.head(3).iterrows()]}")

marl_jev = compute_jev_plus(feed_recs, journeys_df)

print("\n--- MARL 100-USER RESULTS ---")
print("--- Feed Page Metrics ---")
print(f"Feed CTR: {feed_ctr:.4f}")
print(f"Feed Recall@10: {feed_recall:.4f}")
print(f"Feed NDCG@10: {feed_ndcg:.4f}")

print("--- Video Page Metrics ---")
print(f"Video Avg Videoplaytime: {video_videotime:.2f}")
print(f"Video Recall@5: {video_recall:.4f}")
print(f"Video NDCG@5: {video_ndcg:.4f}")

print("--- Joint Optimization Results ---")
print(f"Joint Utility (Feed CTR + Video Videoplaytime): {total_utility:.4f}")
print(f"MARL JEV+: {marl_jev:.6f}")

print(f"\n[INFO] Training Time: {marl_time:.2f} seconds")
print(f"[INFO] Final Joint Loss: {joint_losses[-1]:.6f}")


# Import confidence interval functions
from confidence_intervals import bootstrap_metric, bootstrap_videotime_metric

# Compute confidence intervals for each metric
print("\n--- FEED CTR CONFIDENCE INTERVAL ---")
feed_ctr_ci = bootstrap_metric(
    compute_ctr, feed_recs, feed_positive, 
    n_bootstrap=500, confidence_level=0.95, metric_name="MARL Feed CTR"
)

print("\n--- FEED RECALL@10 CONFIDENCE INTERVAL ---")
feed_recall_ci = bootstrap_metric(
    compute_recall_at_k, feed_recs, feed_positive, 
    n_bootstrap=500, confidence_level=0.95, metric_name="MARL Feed Recall@10", k=10
)

print("\n--- FEED NDCG@10 CONFIDENCE INTERVAL ---")
feed_ndcg_ci = bootstrap_metric(
    compute_ndcg_at_k, feed_recs, feed_positive, 
    n_bootstrap=500, confidence_level=0.95, metric_name="MARL Feed NDCG@10", k=10
)

print("\n--- VIDEO RECALL@5 CONFIDENCE INTERVAL ---")
video_recall_ci = bootstrap_metric(
    compute_recall_at_k, video_recs, video_positive, 
    n_bootstrap=500, confidence_level=0.95, metric_name="MARL Video Recall@5", k=5
)

print("\n--- VIDEO NDCG@5 CONFIDENCE INTERVAL ---")
video_ndcg_ci = bootstrap_metric(
    compute_ndcg_at_k, video_recs, video_positive, 
    n_bootstrap=500, confidence_level=0.95, metric_name="MARL Video NDCG@5", k=5
)

print("\n--- VIDEO PLAYTIME CONFIDENCE INTERVAL ---")
video_playtime_ci = bootstrap_videotime_metric(
    video_recs, video_df_test, n_bootstrap=500, confidence_level=0.95
)

print("\n" + "="*80)
print("MARL CONFIDENCE INTERVAL SUMMARY")
print("="*80)

# Create summary table
marl_metrics_summary = [
    ("Feed CTR", feed_ctr_ci),
    ("Feed Recall@10", feed_recall_ci),
    ("Feed NDCG@10", feed_ndcg_ci),
    ("Video Recall@5", video_recall_ci),
    ("Video NDCG@5", video_ndcg_ci),
    ("Video Playtime", video_playtime_ci)
]

print(f"{'Metric':<20} {'Mean':<12} {'95% CI':<25} {'Std Dev':<12}")
print("-" * 70)

for metric_name, ci_results in marl_metrics_summary:
    mean_val = ci_results['mean']
    ci_lower = ci_results['ci_lower']
    ci_upper = ci_results['ci_upper']
    std_val = ci_results['std']
    
    ci_str = f"[{ci_lower:.4f}, {ci_upper:.4f}]"
    
    print(f"{metric_name:<20} {mean_val:<12.4f} {ci_str:<25} {std_val:<12.4f}")

print("-" * 70)

# Statistical interpretation
print(f"\n{'='*80}")
print("STATISTICAL INTERPRETATION")
print(f"{'='*80}")


print(f"\MARL Performance Assessment:")
if feed_ctr > 0.02:
    print("  Feed CTR appears reasonable for MARL approach")
else:
    print("  Feed CTR is low - may need algorithm tuning")
if marl_jev > 0:
    print("  JEV+ is positive - good end-to-end engagement")
else:
    print("  JEV+ is zero/negative - may need journey optimization")
